package com.showeralarm

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.pm.PackageInfoCompat
import java.net.URL
import kotlin.concurrent.thread

private const val BASE = "https://github.com/epitahh/ShowerAlarm/releases/latest/download"

fun Context.versionCode() = PackageInfoCompat.getLongVersionCode(packageManager.getPackageInfo(packageName, 0))
fun Context.versionName(): String = packageManager.getPackageInfo(packageName, 0).versionName!!

/** 최신 Release의 version.txt(빌드 번호)가 현재 versionCode보다 크면 ask(최신 버전 이름)를 호출. 진행 상황은 status로 알림 */
fun Context.checkUpdate(status: (String) -> Unit, ask: (String) -> Unit) = thread {
    try {
        status("업데이트 확인 중…")
        val latest = URL("$BASE/version.txt").readText().trim().toLong()
        if (latest <= versionCode()) return@thread status("최신 버전")
        val name = URL("$BASE/name.txt").readText().trim()
        status("v$name 업데이트 있음")
        ask(name)
    } catch (e: Exception) {
        status("업데이트 확인 실패: ${e.message}")
    }
}

/** 최신 APK를 받아 자기 자신을 업데이트 */
fun Context.installUpdate(latest: String, status: (String) -> Unit) = thread {
    try {
        if (!packageManager.canRequestPackageInstalls()) {
            status("v$latest 업데이트 있음: 설치 권한 허용 후 앱을 다시 열어 주세요")
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return@thread
        }
        val pi = packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            if (Build.VERSION.SDK_INT >= 31) setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        pi.openSession(pi.createSession(params)).use { s ->
            val conn = URL("$BASE/ShowerAlarm.apk").openConnection()
            val total = conn.contentLengthLong
            conn.getInputStream().use { input ->
                s.openWrite("apk", 0, total).use { out ->
                    val buf = ByteArray(1 shl 16)
                    var done = 0L
                    var shown = -1L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (done * 100 / total != shown) { shown = done * 100 / total; status("v$latest 다운로드 중 $shown% (앱을 닫지 마세요)") }
                    }
                    s.fsync(out)
                }
            }
            status("v$latest 설치 중… (앱이 잠시 종료됩니다)")
            s.commit(
                PendingIntent.getBroadcast(
                    this, 3, Intent(this, InstallReceiver::class.java),
                    PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                ).intentSender
            )
        }
    } catch (e: Exception) {
        status("업데이트 실패: ${e.message}")
    }
}

/** 확인이 필요하면 시스템 확인 화면을 띄우고, 실패하면 이유를 표시 */
class InstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, 0)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION ->
                c.startActivity(i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            PackageInstaller.STATUS_SUCCESS -> {}
            else -> Toast.makeText(c, "업데이트 실패: ${i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)}", Toast.LENGTH_LONG).show()
        }
    }
}
