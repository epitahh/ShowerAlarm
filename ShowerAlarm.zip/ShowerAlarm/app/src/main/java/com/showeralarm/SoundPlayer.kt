package com.showeralarm

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper

/** 알람음 목록 저장 형식: 줄바꿈으로 이어 붙임 (항목 ""는 휴대폰 기본 알람음) */
fun soundsOf(s: String) = s.split("\n")
fun joinSounds(l: List<String>) = l.joinToString("\n")

/** 알람음 바꾸는 간격(초). 알람 데이터와 따로 저장, 기본 30초 */
fun Context.gapOf(id: Int) = prefs().getInt("gap$id", 30)
fun Context.setGap(id: Int, sec: Int) = prefs().edit().putInt("gap$id", sec).apply()

/** 알람음 목록을 순서대로 gapMs마다 바꿔 반복 재생 (알람 울릴 때·미리듣기 공용) */
class SoundPlayer(private val c: Context, private val sounds: List<String>, private val gapMs: Long) {
    private val h = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null // 지금 재생 중
    private var nx: MediaPlayer? = null // 끝나면 바로 이어 재생될 같은 소리
    private var i = 0
    var volume = 1f
        set(v) { field = v; mp?.setVolume(v, v); nx?.setVolume(v, v) }

    private val next = object : Runnable {
        override fun run() {
            i = (i + 1) % sounds.size
            play()
            h.postDelayed(this, gapMs)
        }
    }

    fun start() {
        play()
        if (sounds.size > 1) h.postDelayed(next, gapMs)
    }

    private fun make() = MediaPlayer().apply {
        setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        setDataSource(c, c.soundUri(sounds[i]))
        setVolume(volume, volume)
        prepare()
    }

    private fun play() {
        release()
        mp = make().apply { start() }
        chain()
    }

    /**
     * isLooping은 반복 사이에 틈이 생겨, 미리 준비한 다음 플레이어를 setNextMediaPlayer로 이어 붙임
     * (끝난 플레이어는 해제하고 새 다음 플레이어를 준비. StackOverflow "Android: gapless audio looping"의 방식)
     */
    private fun chain() {
        nx = make()
        mp!!.setNextMediaPlayer(nx)
        mp!!.setOnCompletionListener { it.release(); mp = nx; chain() }
    }

    private fun release() { mp?.release(); nx?.release(); mp = null; nx = null }

    fun stop() { h.removeCallbacks(next); release() }
}
