package com.showeralarm

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity

/**
 * 물건 찾기 후보 고르기 (알라미 방식): 상단 분류 탭 → 해당 분류로 이동, 전체 선택,
 * 분류별 3열 카드(체크박스 · 아이콘 · 이름). 결과는 extra "objects"(라벨 배열)로 돌려줌
 */
class ObjectPickerActivity : ComponentActivity() {
    private val boxes = linkedMapOf<String, CheckBox>()
    private lateinit var all: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val selected = intent.getStringArrayExtra("objects")!!.toSet()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 0, 32, 32) }
        val headers = mutableMapOf<String, View>()

        all = CheckBox(this).apply {
            text = "전체 (${OBJECTS.size})"
            setOnClickListener { boxes.values.forEach { x -> x.isChecked = isChecked } }
        }
        content.addView(all)

        for ((cat, items) in CATEGORIES) {
            content.addView(TextView(this).apply {
                text = cat; textSize = 18f; setPadding(8, 40, 8, 16)
            }.also { headers[cat] = it })
            content.addView(GridLayout(this).apply {
                columnCount = 3
                items.forEach { o -> addView(card(o, o.label in selected)) }
            })
        }
        scroll.addView(content)
        updateAll()

        val tabs = LinearLayout(this).apply {
            setPadding(16, 8, 16, 8)
            CATEGORIES.keys.forEach { cat ->
                addView(Button(context).apply {
                    text = cat
                    background = round(0xFFE8EAF6.toInt(), 60f)
                    setPadding(36, 0, 36, 0)
                    setOnClickListener { scroll.smoothScrollTo(0, headers[cat]!!.top) }
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = 16 })
            }
        }

        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 16, 16, 0)
            addView(Button(context).apply { text = "취소"; setOnClickListener { finish() } })
            addView(TextView(context).apply {
                text = "미션 물건 고르기"; textSize = 18f; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(Button(context).apply {
                text = "확인"
                setOnClickListener {
                    val result = boxes.filterValues { it.isChecked }.keys.toTypedArray()
                    setResult(RESULT_OK, Intent().putExtra("objects", result))
                    finish()
                }
            })
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(top)
            addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(tabs) })
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
    }

    /** 체크박스(좌상단) · 아이콘 · 이름이 있는 카드. 카드 아무 곳이나 누르면 선택 전환 */
    private fun card(o: Obj, checked: Boolean): View {
        val box = CheckBox(this).apply { isChecked = checked; setOnCheckedChangeListener { _, _ -> updateAll() } }
        boxes[o.label] = box
        return FrameLayout(this).apply {
            background = round(0xFFF1F3F4.toInt(), 28f)
            setOnClickListener { box.isChecked = !box.isChecked }
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, 56, 0, 24)
                addView(TextView(context).apply { text = o.icon; textSize = 40f; gravity = Gravity.CENTER })
                addView(TextView(context).apply { text = o.name; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY) })
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
            layoutParams = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f)).apply {
                width = 0; setMargins(12, 12, 12, 12)
            }
        }
    }

    private fun updateAll() { all.isChecked = boxes.values.all { it.isChecked } }

    private fun round(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }
}
