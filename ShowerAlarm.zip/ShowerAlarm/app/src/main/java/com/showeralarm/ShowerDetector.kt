package com.showeralarm

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import android.content.Context
import android.graphics.*
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.max

/** 1) ML Kit 포즈로 전신·서 있음 확인  2) NudeNet(320n)으로 옷 가림 라벨이 없는지 확인 */
class ShowerDetector(c: Context) {
    private val pose = PoseDetection.getClient(
        PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build()
    )
    private val env = OrtEnvironment.getEnvironment()
    private val nude = env.createSession(c.assets.open("320n.onnx").readBytes())

    /** null이면 통과, 아니면 실패 사유 */
    fun check(bmp: Bitmap): String? {
        val p = Tasks.await(pose.process(InputImage.fromBitmap(bmp, 0)))
        val lm = p.allPoseLandmarks
        if (lm.size < 33 || lm.any { it.inFrameLikelihood < IN_FRAME }) return "머리부터 발끝까지 화면에 보이게 서 주세요"

        fun mid(a: Int, b: Int) = p.getPoseLandmark(a)!!.position.let { pa ->
            p.getPoseLandmark(b)!!.position.let { pb -> PointF((pa.x + pb.x) / 2, (pa.y + pb.y) / 2) }
        }
        val s = mid(PoseLandmark.LEFT_SHOULDER, PoseLandmark.RIGHT_SHOULDER)
        val h = mid(PoseLandmark.LEFT_HIP, PoseLandmark.RIGHT_HIP)
        val k = mid(PoseLandmark.LEFT_KNEE, PoseLandmark.RIGHT_KNEE)
        val a = mid(PoseLandmark.LEFT_ANKLE, PoseLandmark.RIGHT_ANKLE)
        if (!(s.y < h.y && h.y < k.y && k.y < a.y) || a.y - s.y < 2 * abs(a.x - s.x)) return "똑바로 서 주세요"

        val found = detect(bmp)
        if (found.any { it in COVERED }) return "옷이 감지됐어요"
        return null
    }

    // 전처리·후처리는 NudeNet 원본(nudenet.py)과 동일: 우·하단 검은 패딩 → 320 리사이즈 → RGB/255, 점수 0.25 이상
    private fun detect(bmp: Bitmap): Set<String> {
        val sc = 320f / max(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(320, 320, Bitmap.Config.ARGB_8888)
        Canvas(sq).apply { drawColor(Color.BLACK) }
            .drawBitmap(bmp, Matrix().apply { setScale(sc, sc) }, Paint(Paint.FILTER_BITMAP_FLAG))
        val px = IntArray(320 * 320).also { sq.getPixels(it, 0, 320, 0, 0, 320, 320) }
        val buf = FloatBuffer.allocate(3 * 320 * 320)
        for (ch in 0..2) for (v in px) buf.put(((v shr (16 - 8 * ch)) and 0xFF) / 255f)
        buf.rewind()
        OnnxTensor.createTensor(env, buf, longArrayOf(1, 3, 320, 320)).use { t ->
            nude.run(mapOf("images" to t)).use { r ->
                @Suppress("UNCHECKED_CAST")
                val o = (r[0].value as Array<Array<FloatArray>>)[0] // [22][2100]
                return o[0].indices.mapNotNull { i ->
                    val best = (4 until 22).maxBy { o[it][i] }
                    if (o[best][i] >= SCORE) LABELS[best - 4] else null
                }.toSet()
            }
        }
    }

    companion object {
        const val IN_FRAME = 0.5f
        const val SCORE = 0.25f
        val LABELS = listOf(
            "FEMALE_GENITALIA_COVERED", "FACE_FEMALE", "BUTTOCKS_EXPOSED", "FEMALE_BREAST_EXPOSED",
            "FEMALE_GENITALIA_EXPOSED", "MALE_BREAST_EXPOSED", "ANUS_EXPOSED", "FEET_EXPOSED",
            "BELLY_COVERED", "FEET_COVERED", "ARMPITS_COVERED", "ARMPITS_EXPOSED", "FACE_MALE",
            "BELLY_EXPOSED", "MALE_GENITALIA_EXPOSED", "ANUS_COVERED", "FEMALE_BREAST_COVERED", "BUTTOCKS_COVERED"
        )
        val COVERED = setOf(
            "FEMALE_GENITALIA_COVERED", "BELLY_COVERED", "ARMPITS_COVERED",
            "ANUS_COVERED", "FEMALE_BREAST_COVERED", "BUTTOCKS_COVERED"
        )
    }
}
