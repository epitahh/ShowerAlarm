package com.showeralarm

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/** 2초 연속으로 조건을 만족해야 알람 해제. 프레임은 저장하지 않음 */
class AlarmActivity : ComponentActivity() {
    private val exec = Executors.newSingleThreadExecutor()
    private var since = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })

        val pv = PreviewView(this)
        val tv = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(0x88000000.toInt())
            setPadding(40, 40, 40, 40)
        }
        // 임시: 인식이 안 될 때를 위한 비상 해제 버튼
        val emergency = Button(this).apply { text = "비상 해제"; setOnClickListener { stopAlarm() } }
        setContentView(FrameLayout(this).apply {
            addView(pv); addView(tv)
            addView(emergency, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = 120 })
        })

        val det = ShowerDetector(this)
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val preview = Preview.Builder().build().apply { setSurfaceProvider(pv.surfaceProvider) }
            val ana = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            ana.setAnalyzer(exec) { img ->
                val raw = img.toBitmap()
                val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
                img.close()
                val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                val msg = det.check(bmp)
                val now = System.currentTimeMillis()
                since = if (msg != null) 0L else if (since == 0L) now else since
                runOnUiThread {
                    tv.text = msg ?: "확인 중… ${(now - since) / 1000}초"
                    if (msg == null && now - since >= HOLD_MS) stopAlarm()
                }
            }
            f.get().bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, ana)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopAlarm() {
        prefs().edit().putBoolean("ringing", false).apply()
        stopService(Intent(this, AlarmService::class.java))
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdown()
    }

    companion object { const val HOLD_MS = 2000L }
}
