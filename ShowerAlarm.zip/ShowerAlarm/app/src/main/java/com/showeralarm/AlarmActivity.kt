package com.showeralarm

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.util.concurrent.Executors

/** 알람에 지정한 미션을 순서대로 수행해야 해제. 프레임은 저장하지 않음 */
class AlarmActivity : ComponentActivity() {
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var keys: List<String>
    private lateinit var objects: List<String>
    // 완료한 미션 수. 화면 회전 등으로 화면이 새로 만들어져도 이어서 하도록 저장해 둠
    private var idx = 0
    @Volatile private var cur: Mission? = null

    private fun mission(k: String): Mission = when (k) {
        "shower" -> ShowerMission(this)
        "object" -> ObjectMission(objects)
        else -> PushupMission(k.substringAfter(":").toInt())
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })
        fun list(key: String) = JSONArray(prefs().getString(key, "[]")).let { a -> List(a.length()) { a.getString(it) } }
        keys = list("missions")
        idx = prefs().getInt("missionIdx", 0)
        objects = list("objects")

        val pv = PreviewView(this)
        fun text(size: Float) = TextView(this).apply { textSize = size; setTextColor(Color.WHITE) }
        val title = text(24f)
        val status = text(20f)
        val skip = Button(this).apply {
            text = "해당 물건이 없어요"
            visibility = View.GONE
            setOnClickListener { (cur as? ObjectMission)?.skip() }
        }
        // 임시: 인식이 안 될 때를 위한 비상 해제 버튼
        val emergency = Button(this).apply { text = "비상 해제"; setOnClickListener { stopAlarm() } }
        setContentView(FrameLayout(this).apply {
            addView(pv)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(0x88000000.toInt())
                setPadding(40, 40, 40, 40)
                addView(title); addView(status); addView(skip)
            })
            addView(emergency, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = 120 })
        })

        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val provider = f.get()
            val preview = Preview.Builder().build().apply { setSurfaceProvider(pv.surfaceProvider) }
            val ana = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            fun bind(back: Boolean) {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, if (back) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA, preview, ana
                )
            }
            ana.setAnalyzer(exec) { img ->
                if (idx >= keys.size) return@setAnalyzer img.close()
                val raw = img.toBitmap()
                val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
                img.close()
                val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                val mission = cur ?: mission(keys[idx]).also { cur = it }
                val msg = mission.step(bmp)
                runOnUiThread {
                    title.text = "미션 ${idx + 1}/${keys.size} · ${mission.title()}"
                    status.text = msg ?: "완료!"
                    skip.visibility = if (mission is ObjectMission) View.VISIBLE else View.GONE
                }
                if (msg != null) return@setAnalyzer
                idx++
                prefs().edit().putInt("missionIdx", idx).apply()
                cur = null
                if (idx == keys.size) runOnUiThread { stopAlarm() }
                else if ((keys[idx] == "object") != mission.back) runOnUiThread { bind(keys[idx] == "object") }
            }
            if (idx < keys.size) bind(keys[idx] == "object") else stopAlarm()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopAlarm() {
        prefs().edit().putBoolean("ringing", false).apply()
        stopService(Intent(this, AlarmService::class.java))
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdown()
    }
}
