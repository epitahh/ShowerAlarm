package com.showeralarm

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.util.concurrent.Executors

/** 알람에 지정한 미션을 순서대로 수행해야 해제. 프레임은 저장하지 않음 */
class AlarmActivity : ComponentActivity() {
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var keys: List<String>
    private lateinit var objects: List<String>
    // 완료한 미션 수. 화면 회전 등으로 화면이 새로 만들어져도 이어서 하도록 저장해 둠
    private var idx = 0
    @Volatile private var cur: Mission? = null
    @Volatile private var back = false // 지금 후면 카메라인지
    private var bindCam: (Boolean) -> Unit = {}

    private fun mission(k: String): Mission = when (k) {
        "shower" -> ShowerMission(this)
        "object" -> ObjectMission(objects)
        else -> PushupMission(this, k.substringAfter(":").toInt())
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // 테스트 모드(설정 화면의 미션 테스트): 알람·저장 없이 intent로 받은 미션만 수행, 뒤로가기 가능
        val test = intent.getBooleanExtra("test", false)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(!test) {
            override fun handleOnBackPressed() {}
        })
        fun list(key: String) = JSONArray(prefs().getString(key, "[]")).let { a -> List(a.length()) { a.getString(it) } }
        if (test) {
            keys = intent.getStringArrayExtra("missions")!!.toList()
            objects = intent.getStringArrayExtra("objects")!!.toList()
        } else {
            keys = list("missions")
            idx = prefs().getInt("missionIdx", 0)
            objects = list("objects")
        }

        val pv = PreviewView(this)
        fun text(size: Float) = TextView(this).apply { textSize = size; setTextColor(Color.WHITE) }
        val title = text(24f)
        val status = text(20f)
        val skip = Button(this).apply {
            text = "해당 물건이 없어요"
            visibility = View.GONE
            setOnClickListener { (cur as? ObjectMission)?.skip() }
        }
        // 알람 중: 소리 줄이기 (설정한 시간·비율), 테스트 중: 테스트 종료
        val bottomBtn = Button(this).apply {
            text = if (test) "테스트 종료" else "소리 줄이기 (${prefs().getInt("quietSec", 10)}초)"
            setOnClickListener {
                if (test) finish() else startService(Intent(this@AlarmActivity, AlarmService::class.java).setAction(QUIET))
            }
        }
        val flip = Button(this).apply { text = "카메라 전환"; setOnClickListener { bindCam(!back) } }
        val overlay = OverlayView(this)
        // 왼쪽 아래 아이콘: 🦴 스켈레톤 표시, 🔔 푸시업 카운트 소리 (누를 때마다 켜고 끔, 꺼지면 흐리게)
        fun toggle(icon: String, key: String) = TextView(this).apply {
            text = icon; textSize = 30f; setPadding(24, 0, 24, 0)
            alpha = if (prefs().getBoolean(key, true)) 1f else 0.35f
            setOnClickListener {
                val on = !prefs().getBoolean(key, true)
                prefs().edit().putBoolean(key, on).apply()
                alpha = if (on) 1f else 0.35f
            }
        }
        val skeletonBtn = toggle("🦴", "showSkeleton")
        val soundBtn = toggle("🔔", "repSound")
        setContentView(FrameLayout(this).apply {
            addView(pv)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(0x88000000.toInt())
                setPadding(40, 40, 40, 40)
                addView(title); addView(status); addView(skip)
            })
            addView(overlay) // 반투명 안내 영역 위에 그려야 어둡게 가려지지 않음
            addView(bottomBtn, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = 120 })
            addView(flip, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END
            ).apply { bottomMargin = 120; marginEnd = 40 })
            addView(LinearLayout(context).apply { addView(skeletonBtn); addView(soundBtn) }, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START
            ).apply { bottomMargin = 120; marginStart = 24 })
        })

        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val provider = f.get()
            val preview = Preview.Builder().build().apply { setSurfaceProvider(pv.surfaceProvider) }
            val ana = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            fun bind(b: Boolean) {
                back = b
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, if (b) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA, preview, ana
                )
            }
            bindCam = ::bind
            ana.setAnalyzer(exec) { img ->
                if (idx >= keys.size) return@setAnalyzer img.close()
                val raw = img.toBitmap()
                val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
                img.close()
                val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                val mission = cur ?: mission(keys[idx]).also { cur = it }
                val msg = mission.step(bmp, back)
                runOnUiThread {
                    title.text = "미션 ${idx + 1}/${keys.size} · ${mission.title()}"
                    status.text = msg ?: "완료!"
                    skip.visibility = if (mission is ObjectMission) View.VISIBLE else View.GONE
                    // 스켈레톤 아이콘은 샤워·푸시업, 소리 아이콘은 푸시업에서만
                    skeletonBtn.visibility = if (mission is ObjectMission) View.GONE else View.VISIBLE
                    soundBtn.visibility = if (mission is PushupMission) View.VISIBLE else View.GONE
                    overlay.set(if (prefs().getBoolean("showSkeleton", true)) mission.overlay else null, bmp.width, bmp.height, !back)
                }
                if (msg != null) return@setAnalyzer
                mission.close()
                idx++
                if (!test) prefs().edit().putInt("missionIdx", idx).apply()
                cur = null
                if (idx == keys.size) runOnUiThread {
                    if (test) { Toast.makeText(this, "테스트 통과!", Toast.LENGTH_SHORT).show(); finish() } else stopAlarm()
                }
                // 다음 미션은 기본 카메라(물건 찾기는 후면, 나머지는 전면)로 시작
                else if ((keys[idx] == "object") != back) runOnUiThread { bind(keys[idx] == "object") }
            }
            if (idx < keys.size) bind(keys[idx] == "object") else stopAlarm()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopAlarm() {
        prefs().edit().putBoolean("ringing", false).apply()
        stopService(Intent(this, AlarmService::class.java))
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdown()
        cur?.close()
    }
}
