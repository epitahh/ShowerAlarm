package com.showeralarm

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var list: LinearLayout
    private val fmt = SimpleDateFormat("M/d HH:mm", Locale.KOREA)
    private var onSoundPicked: (String) -> Unit = {}

    // 고른 파일은 재부팅 후에도 읽을 수 있도록 영구 읽기 권한을 받아 둠
    private val pickSound = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            onSoundPicked(uri.toString())
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            .launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        checkUpdate()

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                addView(Button(context).apply { text = "알람 추가"; setOnClickListener { chooseType() } })
                addView(list)
            })
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // 알람 추가 순서: 종류 → 시각/시간 → 커지는 시간 → 알람음
    private fun chooseType() {
        AlertDialog.Builder(this).setItems(arrayOf("특정 시각", "화면 끈 뒤 n시간")) { _, w ->
            if (w == 0) TimePickerDialog(this, { _, h, m -> configure { r, s -> add(false, h, m, 0, r, s) } }, 7, 0, true).show()
            else chooseDuration()
        }.show()
    }

    private fun chooseDuration() {
        val hours = EditText(this).apply { hint = "시간"; inputType = InputType.TYPE_CLASS_NUMBER }
        val mins = EditText(this).apply { hint = "분"; inputType = InputType.TYPE_CLASS_NUMBER }
        AlertDialog.Builder(this)
            .setTitle("화면 끈 뒤 몇 시간 후?")
            .setView(box(hours, mins))
            .setPositiveButton("확인") { _, _ ->
                val ms = ((hours.text.toString().toLongOrNull() ?: 0) * 60 + (mins.text.toString().toLongOrNull() ?: 0)) * 60_000
                if (ms > 0) configure { r, s -> add(true, 0, 0, ms, r, s) }
            }.show()
    }

    private fun configure(done: (Long, String) -> Unit) {
        val sec = EditText(this).apply { hint = "초 (0이면 처음부터 최대)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("30") }
        AlertDialog.Builder(this)
            .setTitle("소리가 최대가 될 때까지 몇 초?")
            .setView(box(sec))
            .setPositiveButton("확인") { _, _ ->
                val ramp = (sec.text.toString().toLongOrNull() ?: 0) * 1000
                AlertDialog.Builder(this).setTitle("알람음").setItems(arrayOf("기본 알람음", "파일에서 선택")) { _, w ->
                    if (w == 0) done(ramp, "")
                    else {
                        onSoundPicked = { done(ramp, it) }
                        pickSound.launch(arrayOf("audio/*"))
                    }
                }.show()
            }.show()
    }

    private fun box(vararg v: EditText) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(48, 0, 48, 0)
        v.forEach { addView(it) }
    }

    private fun add(screen: Boolean, h: Int, m: Int, dur: Long, ramp: Long, sound: String) {
        val l = loadAlarms()
        l.add(Alarm((l.maxOfOrNull { it.id } ?: 0) + 1, screen, h, m, dur, ramp, sound, true, 0))
        sync(l)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        for (a in loadAlarms()) list.addView(Switch(this).apply {
            textSize = 18f
            setPadding(0, 24, 0, 24)
            text = (if (a.screen) "화면 끈 뒤 ${a.dur / 3_600_000}시간 ${a.dur / 60_000 % 60}분"
            else "%02d:%02d".format(a.h, a.m)) +
                    "\n커짐 ${a.ramp / 1000}초 · ${if (a.sound.isEmpty()) "기본 알람음" else "파일 알람음"}" +
                    if (a.on && a.at > 0) "\n예정: ${fmt.format(a.at)}" else ""
            isChecked = a.on
            setOnCheckedChangeListener { _, on ->
                val l = loadAlarms()
                l.first { it.id == a.id }.apply { this.on = on; at = 0 }
                sync(l)
                list.post { refresh() }
            }
        })
    }
}
