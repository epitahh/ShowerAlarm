package com.showeralarm

import android.Manifest
import android.app.ActionBar
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var list: LinearLayout
    private lateinit var addBtn: TextView
    private lateinit var updateText: TextView
    private lateinit var selectBar: LinearLayout
    private lateinit var selectCount: TextView
    private lateinit var nextText: TextView
    private val tick = Handler(Looper.getMainLooper())
    private val updateNext = object : Runnable {
        override fun run() { showNext(); tick.postDelayed(this, 30_000) }
    }
    private var selected: MutableSet<Int>? = null // null이면 일반 모드, 아니면 선택 모드(선택된 알람 id)
    // 이번에 스위치로 끈 반복 알람 (이 알람에만 '다음 알람만 건너뛰고 켜기' 버튼 표시)
    private val justOff = mutableSetOf<Int>()
    private val fmt = SimpleDateFormat("M/d HH:mm", Locale.KOREA)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            .launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        // 현재 버전과 업데이트 진행 상황 표시 (끝의 '(업데이트 확인)'을 누르면 다시 확인)
        updateText = TextView(this).apply { movementMethod = LinkMovementMethod.getInstance() }
        nextText = TextView(this).apply { textSize = 20f; setPadding(0, 24, 0, 24) }
        check()

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // 최상단 우측 아이콘: + 알람 추가, ⚙ 설정 (버튼 모양 없이 글자만)
        // 상단 바(앱 이름 줄) 오른쪽 아이콘: + 알람 추가, ⚙ 설정 (버튼 모양 없이 글자만)
        fun icon(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 34f; setPadding(40, 0, 24, 0); setOnClickListener { f() }
            // 글자 위아래 여백을 없애고 상단 바 높이 안에서 가운데 정렬
            gravity = Gravity.CENTER; includeFontPadding = false
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        addBtn = icon("+") { startActivity(Intent(this@MainActivity, EditActivity::class.java)) }
        actionBar!!.apply {
            setDisplayShowCustomEnabled(true)
            setCustomView(LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(addBtn)
                addView(icon("⚙") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) })
            }, ActionBar.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END or Gravity.CENTER_VERTICAL))
        }
        // 선택 모드 도구 모음: 선택 개수 · 복사 · 삭제 · 취소
        selectCount = TextView(this).apply { textSize = 18f }
        // 선택 모드 도구 모음: 선택 개수 / 복사 · 삭제 · 연결 · 해제 · 취소
        fun act(t: String, f: () -> Unit) = Button(this).apply {
            text = t; minWidth = 0; minimumWidth = 0; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        selectBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(selectCount)
            addView(LinearLayout(context).apply {
                addView(act("복사") { copySelected() })
                addView(act("삭제") { deleteSelected() })
                addView(act("연결") { linkSelected(true) })
                addView(act("해제") { linkSelected(false) })
                addView(act("취소") { setSelecting(null) })
            })
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() = setSelecting(null)
        }.also { backCb = it })
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                addView(updateText)
                addView(nextText)
                addView(selectBar)
                addView(list)
            })
        })
    }

    private lateinit var backCb: OnBackPressedCallback

    private fun status(s: String) = runOnUiThread {
        updateText.text = SpannableStringBuilder("현재 v${versionName()} · $s ").append("(업데이트 확인)", object : ClickableSpan() {
            override fun onClick(v: View) = check()
        }, 0)
    }

    private fun check() {
        checkUpdate(::status) { latest ->
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setMessage("업데이트가 있습니다. (v$latest)\n업데이트 하시겠습니까?")
                    .setPositiveButton("예") { _, _ -> installUpdate(latest, ::status) }
                    .setNegativeButton("아니오", null)
                    .show()
            }
        }
    }
    private var permDialog: AlertDialog? = null

    /** 알람이 울릴 때 화면을 켜고 미션 화면을 띄우는 데 필요한 특수 권한을 하나씩 안내 (허용될 때까지 앱을 열 때마다) */
    private fun askPermission() {
        val uri = Uri.parse("package:$packageName")
        val (name, intent) = when {
            Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent() ->
                "전체 화면 알림" to Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, uri)
            !Settings.canDrawOverlays(this) -> "다른 앱 위에 표시" to Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri)
            else -> return
        }
        if (permDialog?.isShowing == true) return
        permDialog = AlertDialog.Builder(this)
            .setTitle("권한 필요")
            .setMessage("알람이 울릴 때 화면을 켜고 미션 화면을 띄우려면 '$name' 권한이 필요해요.\n목록이 나오면 '샤워 알람'을 찾아 허용해 주세요.")
            .setCancelable(false)
            .setPositiveButton("설정 열기") { _, _ -> startActivity(intent) }
            .show()
    }

    private fun setSelecting(s: MutableSet<Int>?) {
        selected = s
        backCb.isEnabled = s != null
        addBtn.visibility = if (s == null) View.VISIBLE else View.GONE
        selectBar.visibility = if (s == null) View.GONE else View.VISIBLE
        refresh()
    }

    /** 선택한 알람을 같은 설정의 새 알람으로 복사 */
    private fun copySelected() {
        val l = loadAlarms()
        var id = l.maxOf { it.id }
        l += l.filter { it.id in selected!! }.map { it.copy(id = ++id, at = 0) }
        sync(l)
        setSelecting(null)
    }

    /** 선택한 알람을 새 그룹으로 연결(2개 이상) 또는 연결 해제 */
    private fun linkSelected(link: Boolean) {
        val sel = selected!!
        if (link && sel.size < 2) return Toast.makeText(this, "2개 이상 선택해 주세요", Toast.LENGTH_SHORT).show()
        val g = if (link) loadAlarms().maxOf { linkOf(it.id) } + 1 else 0
        sel.forEach { setLink(it, g) }
        setSelecting(null)
    }

    private fun deleteSelected() {
        AlertDialog.Builder(this).setMessage("${selected!!.size}개 알람을 삭제할까요?")
            .setPositiveButton("삭제") { _, _ ->
                val l = loadAlarms()
                l.filter { it.id in selected!! }.forEach { disarm(it) }
                l.removeAll { it.id in selected!! }
                sync(l)
                setSelecting(null)
            }.setNegativeButton("취소", null).show()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        tick.post(updateNext)
        askPermission()
    }

    override fun onPause() {
        super.onPause()
        tick.removeCallbacks(updateNext)
    }

    /** 예약된 알람 중 가장 빠른 것까지 남은 시간 ('화면 끈 뒤' 알람은 화면이 꺼져 예약된 뒤부터 표시) */
    private fun showNext() {
        val next = loadAlarms().filter { it.on && it.at > 0 }.minByOrNull { it.at }
        nextText.text = if (next == null) "예정된 알람 없음" else {
            val min = ((next.at - System.currentTimeMillis()).coerceAtLeast(0) + 59_999) / 60_000
            val d = min / 1440; val h = min / 60 % 24; val m = min % 60
            "다음 알람: " + (if (next.name.isNotEmpty()) "${next.name} · " else "") +
                    (if (d > 0) "${d}일 " else "") + (if (d > 0 || h > 0) "${h}시간 " else "") + "${m}분 후 (${fmt.format(next.at)})"
        }
    }

    /**
     * 알람 카드 (삼성 시계 앱 형태): 이름 / 오전·오후 + 큰 시각 · 가운데 작은 상세 정보 · 스위치 / 요일 줄.
     * 켜져 있던 반복 알람을 방금 끈 경우에만 '다음 알람만 건너뛰고 켜기' 버튼
     */
    // 연결 그룹별 알람 수, 화면에 보일 그룹 번호(1부터)
    private var groups = mapOf<Int, Int>()
    private var groupNo = mapOf<Int, Int>()

    private fun card(a: Alarm, sel: MutableSet<Int>?): View {
        val dim = if (a.on) 1f else 0.45f
        fun t(size: Float, color: Int = 0xFF333333.toInt()) = TextView(this).apply { textSize = size; setTextColor(color); alpha = dim }

        // 큰 시각: 특정 시각은 '오후 3:30', 화면 끈 뒤는 '화면 끈 뒤 7:30'
        val small = t(18f).apply { text = if (a.screen) "화면 끈 뒤 " else if (a.h < 12) "오전 " else "오후 " }
        val big = t(52f).apply {
            text = if (a.screen) "${a.dur / 3_600_000}:%02d".format(a.dur / 60_000 % 60)
            else "${(a.h + 11) % 12 + 1}:%02d".format(a.m)
            includeFontPadding = false
        }
        // 가운데 빈 공간: 나머지 정보 작게
        val skip = skipUntil(a.id)
        val info = t(12f, Color.GRAY).apply {
            text = "미션: " + a.missions.joinToString(" → ") { missionName(it) } +
                    "\n커짐 ${a.ramp / 1000}초 · 최대 ${a.maxVol}%" +
                    "\n${if (a.vibrate) "진동" else "진동 없음"} · ${if (a.sound.isEmpty()) "기본 알람음" else "파일 알람음"}" +
                    (if (a.on && skip > System.currentTimeMillis()) "\n다음 알람 건너뜀 (~${fmt.format(skip)})" else "") +
                    (if (a.on && a.at > 0) "\n예정: ${fmt.format(a.at)}" else "")
            setPadding(24, 0, 16, 0)
        }
        val toggle: View = if (sel != null) CheckBox(this).apply { isChecked = a.id in sel; isClickable = false }
        else Switch(this).apply {
            isChecked = a.on
            setOnCheckedChangeListener { _, on ->
                val l = loadAlarms()
                l.first { it.id == a.id }.apply { this.on = on; at = 0 }
                setSkip(a.id, 0)
                if (!on && a.days != 0) justOff += a.id else justOff -= a.id
                sync(l)
                list.post { refresh() }
            }
        }
        // 요일 줄: 선택한 요일은 굵게 + 위에 점, 지정일·한 번은 글자로
        val days = LinearLayout(this).apply {
            if (a.days != 0) DAYS.forEachIndexed { i, d ->
                val on = ((a.days shr i) and 1) == 1
                addView(t(14f, if (on) 0xFF333333.toInt() else 0xFFBBBBBB.toInt()).apply {
                    text = if (on) "·\n$d" else " \n$d"
                    gravity = Gravity.CENTER
                    setLineSpacing(0f, 0.7f)
                    if (on) setTypeface(null, Typeface.BOLD)
                    setPadding(0, 0, 20, 0)
                })
            } else addView(t(14f, Color.GRAY).apply { text = if (a.date.isNotEmpty()) "${a.date}만" else "한 번" })
            if (a.skipHoliday) addView(t(13f, Color.GRAY).apply { text = "  공휴일 제외"; gravity = Gravity.BOTTOM })
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 32, 40, 32)
            background = GradientDrawable().apply { setColor(0xFFF4F5F8.toInt()); cornerRadius = 40f }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(0, 0, 0, 28) }
            val g = linkOf(a.id)
            val linked = g != 0 && groups[g]!! >= 2
            if (a.name.isNotEmpty() || linked) addView(t(15f, 0xFF555555.toInt()).apply {
                text = (if (linked) "🔗 연결 ${groupNo[g]}  " else "") + a.name
                setTypeface(null, Typeface.BOLD)
            })
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(LinearLayout(context).apply { gravity = Gravity.BOTTOM; addView(small); addView(big) })
                addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(toggle)
            })
            addView(days)
            if (sel == null && !a.on && a.id in justOff) addView(TextView(context).apply {
                text = "⏰  다음 알람만 건너뛰고 켜기"
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(0xFF333333.toInt())
                setPadding(0, 28, 0, 28)
                background = GradientDrawable().apply { setColor(Color.WHITE); setStroke(2, 0xFFDDDDDD.toInt()); cornerRadius = 100f }
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = 24 }
                setOnClickListener { justOff -= a.id; skipNext(loadAlarms(), a.id); refresh() }
            })
            setOnClickListener {
                if (sel == null) startActivity(Intent(this@MainActivity, EditActivity::class.java).putExtra("id", a.id))
                else {
                    if (!sel.remove(a.id)) sel += a.id
                    if (sel.isEmpty()) setSelecting(null) else refresh()
                }
            }
            setOnLongClickListener {
                if (sel == null) setSelecting(mutableSetOf(a.id))
                true
            }
        }
    }

    // 일반 모드: 카드를 누르면 수정, 스위치로 켜고 끄기, 길게 누르면 선택 모드
    // 선택 모드: 누르면 선택 전환, 모두 해제하면 일반 모드로
    private fun refresh() {
        showNext()
        list.removeAllViews()
        val sel = selected
        selectCount.text = "${sel?.size ?: 0}개 선택"
        val l = loadAlarms()
        groups = l.map { linkOf(it.id) }.filter { it != 0 }.groupingBy { it }.eachCount()
        groupNo = groups.filterValues { it >= 2 }.keys.sorted().withIndex().associate { it.value to it.index + 1 }
        for (a in l) list.addView(card(a, sel))
    }
}
