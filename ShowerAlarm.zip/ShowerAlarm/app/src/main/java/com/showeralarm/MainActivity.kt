package com.showeralarm

import android.Manifest
import android.app.ActionBar
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var list: LinearLayout
    private lateinit var addBtn: TextView
    private lateinit var updateText: TextView
    private lateinit var selectBar: LinearLayout
    private lateinit var selectCount: TextView
    private lateinit var nextText: TextView
    private val tick = Handler(Looper.getMainLooper())
    private val updateNext = object : Runnable {
        override fun run() { showNext(); tick.postDelayed(this, 30_000) }
    }
    private var selected: MutableSet<Int>? = null // null이면 일반 모드, 아니면 선택 모드(선택된 알람 id)
    private val fmt = SimpleDateFormat("M/d HH:mm", Locale.KOREA)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            .launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        // 현재 버전과 업데이트 진행 상황 표시 (끝의 '(업데이트 확인)'을 누르면 다시 확인)
        updateText = TextView(this).apply { movementMethod = LinkMovementMethod.getInstance() }
        nextText = TextView(this).apply { textSize = 20f; setPadding(0, 24, 0, 24) }
        check()

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // 최상단 우측 아이콘: + 알람 추가, ⚙ 설정 (버튼 모양 없이 글자만)
        // 상단 바(앱 이름 줄) 오른쪽 아이콘: + 알람 추가, ⚙ 설정 (버튼 모양 없이 글자만)
        fun icon(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 34f; setPadding(40, 0, 24, 0); gravity = Gravity.CENTER_VERTICAL; setOnClickListener { f() }
        }
        addBtn = icon("+") { startActivity(Intent(this@MainActivity, EditActivity::class.java)) }
        actionBar!!.apply {
            setDisplayShowCustomEnabled(true)
            setCustomView(LinearLayout(this@MainActivity).apply {
                addView(addBtn)
                addView(icon("⚙") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) })
            }, ActionBar.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END or Gravity.CENTER_VERTICAL))
        }
        // 선택 모드 도구 모음: 선택 개수 · 복사 · 삭제 · 취소
        selectCount = TextView(this).apply {
            textSize = 18f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        selectBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            addView(selectCount)
            addView(Button(context).apply { text = "복사"; setOnClickListener { copySelected() } })
            addView(Button(context).apply { text = "삭제"; setOnClickListener { deleteSelected() } })
            addView(Button(context).apply { text = "취소"; setOnClickListener { setSelecting(null) } })
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() = setSelecting(null)
        }.also { backCb = it })
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                addView(updateText)
                addView(nextText)
                addView(selectBar)
                addView(list)
            })
        })
    }

    private lateinit var backCb: OnBackPressedCallback

    private fun status(s: String) = runOnUiThread {
        updateText.text = SpannableStringBuilder("현재 v${versionName()} · $s ").append("(업데이트 확인)", object : ClickableSpan() {
            override fun onClick(v: View) = check()
        }, 0)
    }

    private fun check() {
        checkUpdate(::status) { latest ->
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setMessage("업데이트가 있습니다. (v$latest)\n업데이트 하시겠습니까?")
                    .setPositiveButton("예") { _, _ -> installUpdate(latest, ::status) }
                    .setNegativeButton("아니오", null)
                    .show()
            }
        }
    }
    private var permDialog: AlertDialog? = null

    /** 알람이 울릴 때 화면을 켜고 미션 화면을 띄우는 데 필요한 특수 권한을 하나씩 안내 (허용될 때까지 앱을 열 때마다) */
    private fun askPermission() {
        val uri = Uri.parse("package:$packageName")
        val (name, intent) = when {
            Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent() ->
                "전체 화면 알림" to Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, uri)
            !Settings.canDrawOverlays(this) -> "다른 앱 위에 표시" to Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri)
            else -> return
        }
        if (permDialog?.isShowing == true) return
        permDialog = AlertDialog.Builder(this)
            .setTitle("권한 필요")
            .setMessage("알람이 울릴 때 화면을 켜고 미션 화면을 띄우려면 '$name' 권한이 필요해요.\n목록이 나오면 '샤워 알람'을 찾아 허용해 주세요.")
            .setCancelable(false)
            .setPositiveButton("설정 열기") { _, _ -> startActivity(intent) }
            .show()
    }

    private fun setSelecting(s: MutableSet<Int>?) {
        selected = s
        backCb.isEnabled = s != null
        addBtn.visibility = if (s == null) View.VISIBLE else View.GONE
        selectBar.visibility = if (s == null) View.GONE else View.VISIBLE
        refresh()
    }

    /** 선택한 알람을 같은 설정의 새 알람으로 복사 */
    private fun copySelected() {
        val l = loadAlarms()
        var id = l.maxOf { it.id }
        l += l.filter { it.id in selected!! }.map { it.copy(id = ++id, at = 0) }
        sync(l)
        setSelecting(null)
    }

    private fun deleteSelected() {
        AlertDialog.Builder(this).setMessage("${selected!!.size}개 알람을 삭제할까요?")
            .setPositiveButton("삭제") { _, _ ->
                val l = loadAlarms()
                l.filter { it.id in selected!! }.forEach { disarm(it) }
                l.removeAll { it.id in selected!! }
                sync(l)
                setSelecting(null)
            }.setNegativeButton("취소", null).show()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        tick.post(updateNext)
        askPermission()
    }

    override fun onPause() {
        super.onPause()
        tick.removeCallbacks(updateNext)
    }

    /** 예약된 알람 중 가장 빠른 것까지 남은 시간 ('화면 끈 뒤' 알람은 화면이 꺼져 예약된 뒤부터 표시) */
    private fun showNext() {
        val next = loadAlarms().filter { it.on && it.at > 0 }.minByOrNull { it.at }
        nextText.text = if (next == null) "예정된 알람 없음" else {
            val min = ((next.at - System.currentTimeMillis()).coerceAtLeast(0) + 59_999) / 60_000
            val d = min / 1440; val h = min / 60 % 24; val m = min % 60
            "다음 알람: " + (if (next.name.isNotEmpty()) "${next.name} · " else "") +
                    (if (d > 0) "${d}일 " else "") + (if (d > 0 || h > 0) "${h}시간 " else "") + "${m}분 후 (${fmt.format(next.at)})"
        }
    }

    private fun rule(a: Alarm) = when {
        a.days != 0 -> "매주 " + (0..6).filter { ((a.days shr it) and 1) == 1 }.joinToString("·") { DAYS[it] } +
                if (a.skipHoliday) " (공휴일 제외)" else ""
        a.date.isNotEmpty() -> "${a.date}만"
        else -> "한 번"
    }

    // 일반 모드: 글자를 누르면 수정, 스위치로 켜고 끄기, 길게 누르면 선택 모드
    // 선택 모드: 누르면 선택 전환, 모두 해제하면 일반 모드로
    private fun refresh() {
        showNext()
        list.removeAllViews()
        val sel = selected
        selectCount.text = "${sel?.size ?: 0}개 선택"
        for (a in loadAlarms()) list.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 24, 0, 24)
            addView(TextView(context).apply {
                textSize = 18f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                text = SpannableStringBuilder().apply {
                    if (a.name.isNotEmpty()) {
                        append(a.name, StyleSpan(Typeface.BOLD), 0)
                        setSpan(RelativeSizeSpan(1.2f), 0, length, 0)
                        append("\n")
                    }
                }.append((if (a.screen) "화면 끈 뒤 ${a.dur / 3_600_000}시간 ${a.dur / 60_000 % 60}분"
                else "%02d:%02d".format(a.h, a.m)) +
                        "\n${rule(a)}" +
                        "\n미션: ${a.missions.joinToString(" → ") { missionName(it) }}" +
                        "\n커짐 ${a.ramp / 1000}초 · 최대 ${a.maxVol}% · ${if (a.vibrate) "진동" else "진동 없음"}" +
                        " · ${if (a.sound.isEmpty()) "기본 알람음" else "파일 알람음"}" +
                        if (a.on && a.at > 0) "\n예정: ${fmt.format(a.at)}" else "")
                setOnClickListener {
                    if (sel == null) startActivity(Intent(this@MainActivity, EditActivity::class.java).putExtra("id", a.id))
                    else {
                        if (!sel.remove(a.id)) sel += a.id
                        if (sel.isEmpty()) setSelecting(null) else refresh()
                    }
                }
                setOnLongClickListener {
                    if (sel == null) setSelecting(mutableSetOf(a.id))
                    true
                }
            })
            if (sel != null) addView(CheckBox(context).apply { isChecked = a.id in sel; isClickable = false })
            else addView(Switch(context).apply {
                isChecked = a.on
                setOnCheckedChangeListener { _, on ->
                    val l = loadAlarms()
                    l.first { it.id == a.id }.apply { this.on = on; at = 0 }
                    sync(l)
                    list.post { refresh() }
                }
            })
        })
    }
}
