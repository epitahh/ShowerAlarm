package com.showeralarm

import android.Manifest
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            .launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))

        status = TextView(this).apply { textSize = 20f }
        val hours = EditText(this).apply { hint = "시간"; inputType = InputType.TYPE_CLASS_NUMBER }
        val mins = EditText(this).apply { hint = "분"; inputType = InputType.TYPE_CLASS_NUMBER }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            addView(status)
            addView(Button(context).apply {
                text = "특정 시간에 알람"
                setOnClickListener { TimePickerDialog(context, { _, h, m -> setAt(h, m) }, 7, 0, true).show() }
            })
            addView(hours)
            addView(mins)
            addView(Button(context).apply {
                text = "화면 끈 뒤 n시간 후 알람"
                setOnClickListener {
                    val ms = ((hours.text.toString().toLongOrNull() ?: 0) * 60 + (mins.text.toString().toLongOrNull() ?: 0)) * 60_000
                    if (ms > 0) setAfterScreenOff(ms)
                }
            })
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun setAt(h: Int, m: Int) {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DATE, 1)
        }
        stopService(Intent(this, ScreenService::class.java))
        prefs().edit().putLong("dur", 0).apply()
        scheduleAlarm(c.timeInMillis)
        refresh()
    }

    private fun setAfterScreenOff(ms: Long) {
        cancelAlarm()
        prefs().edit().putLong("dur", ms).apply()
        startForegroundService(Intent(this, ScreenService::class.java))
        refresh()
    }

    private fun refresh() {
        val p = prefs()
        val at = p.getLong("at", 0)
        val dur = p.getLong("dur", 0)
        val fmt = SimpleDateFormat("M/d HH:mm", Locale.KOREA)
        status.text = when {
            dur > 0 -> "화면 끈 뒤 ${dur / 3_600_000}시간 ${dur / 60_000 % 60}분 후 알람" +
                    if (at > 0) "\n(현재 예정: ${fmt.format(at)})" else ""
            at > 0 -> "알람: ${fmt.format(at)}"
            else -> "설정된 알람 없음"
        }
    }
}
