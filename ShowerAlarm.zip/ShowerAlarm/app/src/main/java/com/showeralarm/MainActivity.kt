package com.showeralarm

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var list: LinearLayout
    private val fmt = SimpleDateFormat("M/d HH:mm", Locale.KOREA)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            .launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        // 현재 버전과 업데이트 진행 상황 표시
        val updateText = TextView(this)
        val status = { s: String -> runOnUiThread { updateText.text = "현재 v${versionCode()} · $s" } }
        checkUpdate(status) { latest ->
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setMessage("업데이트가 있습니다. (v$latest)\n업데이트 하시겠습니까?")
                    .setPositiveButton("예") { _, _ -> installUpdate(latest, status) }
                    .setNegativeButton("아니오", null)
                    .show()
            }
        }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                addView(updateText)
                addView(Button(context).apply {
                    text = "알람 추가"
                    setOnClickListener { startActivity(Intent(this@MainActivity, EditActivity::class.java)) }
                })
                addView(list)
            })
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun rule(a: Alarm) = when {
        a.days != 0 -> "매주 " + (0..6).filter { ((a.days shr it) and 1) == 1 }.joinToString("·") { DAYS[it] } +
                if (a.skipHoliday) " (공휴일 제외)" else ""
        a.date.isNotEmpty() -> "${a.date}만"
        else -> "한 번"
    }

    // 글자를 누르면 수정 화면, 스위치로 켜고 끄기
    private fun refresh() {
        list.removeAllViews()
        for (a in loadAlarms()) list.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 24, 0, 24)
            addView(TextView(context).apply {
                textSize = 18f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                text = (if (a.screen) "화면 끈 뒤 ${a.dur / 3_600_000}시간 ${a.dur / 60_000 % 60}분"
                else "%02d:%02d".format(a.h, a.m)) +
                        "\n${rule(a)}" +
                        "\n미션: ${a.missions.joinToString(" → ") { MISSIONS[it]!! }}" +
                        "\n커짐 ${a.ramp / 1000}초 · 최대 ${a.maxVol}% · ${if (a.vibrate) "진동" else "진동 없음"}" +
                        " · ${if (a.sound.isEmpty()) "기본 알람음" else "파일 알람음"}" +
                        if (a.on && a.at > 0) "\n예정: ${fmt.format(a.at)}" else ""
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, EditActivity::class.java).putExtra("id", a.id))
                }
            })
            addView(Switch(context).apply {
                isChecked = a.on
                setOnCheckedChangeListener { _, on ->
                    val l = loadAlarms()
                    l.first { it.id == a.id }.apply { this.on = on; at = 0 }
                    sync(l)
                    list.post { refresh() }
                }
            })
        })
    }
}
