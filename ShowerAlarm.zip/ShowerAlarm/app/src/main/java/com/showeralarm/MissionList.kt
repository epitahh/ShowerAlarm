package com.showeralarm

import android.app.AlertDialog
import android.content.Intent
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Collections

/**
 * 해제 미션 목록 편집 (알람 편집 화면 · 설정의 미션 테스트 공용).
 * 미션 추가(중복 허용) · 순서 변경 · 삭제, 물건 찾기 미션을 누르면 후보 선택. Activity의 onCreate에서 만들어야 함
 */
class MissionList(private val a: ComponentActivity, init: List<String>, initObjects: List<String>) {
    val missions = init.toMutableList()
    val objects = initObjects.toMutableList()

    private val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    val view = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        addView(box)
        addView(Button(a).apply { text = "+ 미션 추가"; setOnClickListener { addMission() } })
    }

    private val pickObjects = a.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            objects.clear(); objects += r.data!!.getStringArrayExtra("objects")!!
            render()
        }
    }

    init { render() }

    /** 문제가 있으면 안내 문구, 없으면 null */
    fun error() = when {
        missions.isEmpty() -> "해제 미션을 하나 이상 추가해 주세요"
        "object" in missions && objects.isEmpty() -> "물건 찾기 미션을 눌러 후보를 하나 이상 골라 주세요"
        else -> null
    }

    fun valid() = error()?.let { Toast.makeText(a, it, Toast.LENGTH_SHORT).show(); false } ?: true

    private fun render() {
        box.removeAllViews()
        missions.forEachIndexed { i, k ->
            fun btn(t: String, f: () -> Unit) = Button(a).apply {
                text = t; minWidth = 0; minimumWidth = 0; setOnClickListener { f(); render() }
            }
            box.addView(LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(TextView(a).apply {
                    textSize = 18f
                    setPadding(16, 0, 16, 0)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    if (k == "object") {
                        text = "${i + 1}. 물건 찾기 (후보 ${objects.size}개) ✎"
                        setOnClickListener { chooseObjects() }
                    } else text = "${i + 1}. ${missionName(k)}"
                })
                addView(btn("↑") { if (i > 0) Collections.swap(missions, i, i - 1) })
                addView(btn("↓") { if (i < missions.size - 1) Collections.swap(missions, i, i + 1) })
                addView(btn("✕") { missions.removeAt(i) })
            })
        }
    }

    private fun chooseObjects() =
        pickObjects.launch(Intent(a, ObjectPickerActivity::class.java).putExtra("objects", objects.toTypedArray()))

    private fun addMission() {
        val keys = MISSIONS.keys.toList()
        AlertDialog.Builder(a).setTitle("미션 추가").setItems(MISSIONS.values.toTypedArray()) { _, w ->
            if (keys[w].startsWith("pushup")) {
                val n = NumberPicker(a).apply { minValue = 1; maxValue = 100; value = 10 }
                AlertDialog.Builder(a).setTitle("푸시업 몇 개?").setView(n)
                    .setPositiveButton("확인") { _, _ -> missions += "${keys[w]}:${n.value}"; render() }
                    .show()
            } else { missions += keys[w]; render() }
        }.show()
    }
}
