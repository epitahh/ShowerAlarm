package com.showeralarm

import android.content.Context
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

/** 미션 키: "shower", "object", "pushup:횟수"(바닥), "pushup_shoulder:횟수"(정면·어깨), "pushup_face:횟수"(정면·얼굴) */
val MISSIONS = linkedMapOf(
    "shower" to "샤워 인증", "object" to "물건 찾기",
    "pushup" to "푸시업 (바닥)", "pushup_shoulder" to "푸시업 (정면·어깨)", "pushup_face" to "푸시업 (정면·얼굴)"
)

fun missionName(key: String) =
    if (":" in key) "${MISSIONS[key.substringBefore(":")]} ${key.substringAfter(":")}개" else MISSIONS[key]!!

fun pushupMission(c: Context, key: String): Mission {
    val n = key.substringAfter(":").toInt()
    return when (key.substringBefore(":")) {
        "pushup" -> FloorPushup(c, n)
        "pushup_shoulder" -> ShoulderPushup(c, n)
        else -> FacePushup(c, n)
    }
}

class Obj(val label: String, val name: String, val icon: String)

/** 물건 찾기 후보: ML Kit 이미지 라벨링 기본 모델의 라벨을 알라미처럼 장소·종류별로 분류 */
val CATEGORIES = linkedMapOf(
    "화장실" to listOf(Obj("Sink", "세면대", "🚰"), Obj("Tile", "타일", "🔲")),
    "거실" to listOf(
        Obj("Couch", "소파", "🛋️"), Obj("Cushion", "쿠션", "🟨"), Obj("Clock", "시계", "⏰"),
        Obj("Television", "TV", "📺"), Obj("Piano", "피아노", "🎹"), Obj("Musical instrument", "악기", "🎸"),
        Obj("Lampshade", "전등갓", "💡")
    ),
    "식물" to listOf(Obj("Flowerpot", "화분", "🪴"), Obj("Plant", "식물", "🌿"), Obj("Flower", "꽃", "🌷")),
    "내 소지품" to listOf(
        Obj("Glasses", "안경", "👓"), Obj("Sunglasses", "선글라스", "🕶️"), Obj("Bag", "가방", "🎒"),
        Obj("Handbag", "핸드백", "👜"), Obj("Cap", "모자", "🧢"), Obj("Mobile phone", "휴대폰", "📱"),
        Obj("Lipstick", "립스틱", "💄"), Obj("Ring", "반지", "💍"), Obj("Money", "돈", "💵")
    ),
    "내 방" to listOf(
        Obj("Drawer", "서랍", "🗄️"), Obj("Curtain", "커튼", "🪟"), Obj("Desk", "책상", "🪵"),
        Obj("Pillow", "베개", "🛏️"), Obj("Chair", "의자", "🪑"), Obj("Stuffed toy", "봉제 인형", "🧸"),
        Obj("Cabinetry", "수납장", "🚪"), Obj("Shelf", "선반", "📚"), Obj("Computer", "컴퓨터", "💻"),
        Obj("Jeans", "청바지", "👖"), Obj("Jacket", "재킷", "🧥"), Obj("Poster", "포스터", "🖼️")
    ),
    "주방" to listOf(
        Obj("Cup", "컵", "🥛"), Obj("Tableware", "식기", "🍽️"), Obj("Cutlery", "수저·포크", "🍴"),
        Obj("Cookware and bakeware", "조리기구", "🍳"), Obj("Fruit", "과일", "🍎"), Obj("Vegetable", "채소", "🥦"),
        Obj("Bread", "빵", "🍞"), Obj("Juice", "주스", "🧃"), Obj("Cola", "콜라", "🥤"), Obj("Coffee", "커피", "☕")
    ),
    "사람" to listOf(
        Obj("Hand", "손", "✋"), Obj("Foot", "발", "🦶"), Obj("Ear", "귀", "👂"), Obj("Mouth", "입", "👄"),
        Obj("Smile", "미소", "😊"), Obj("Nail", "손톱", "💅"), Obj("Hair", "머리카락", "💇"), Obj("Beard", "수염", "🧔"),
        Obj("Muscle", "근육", "💪")
    ),
    "현관" to listOf(
        Obj("Shoe", "신발", "👞"), Obj("Sneakers", "운동화", "👟"), Obj("Umbrella", "우산", "☂️"),
        Obj("Stairs", "계단", "🪜"), Obj("Bicycle", "자전거", "🚲"), Obj("Helmet", "헬멧", "⛑️")
    ),
    "동물" to listOf(Obj("Dog", "개", "🐶"), Obj("Cat", "고양이", "🐱"), Obj("Pet", "반려동물", "🐾"))
)

/** 라벨 → 물건 */
val OBJECTS = CATEGORIES.values.flatten().associateBy { it.label }

/** 해제 미션. step()은 카메라 프레임마다 호출되며 안내 문구를 반환, 완료되면 null */
interface Mission {
    val back: Boolean // 후면 카메라 사용 여부
    fun title(): String
    fun step(bmp: Bitmap): String?
    fun close() {}
}

/** 조건이 연속으로 유지된 시간(ms). 끊기면 -1 */
private class Hold {
    private var since = 0L
    fun ms(ok: Boolean): Long {
        val now = System.currentTimeMillis()
        since = if (!ok) 0L else if (since == 0L) now else since
        return if (ok) now - since else -1
    }
}

/** 전신·직립·옷 없음이 2초 연속 확인되면 완료 */
class ShowerMission(c: Context) : Mission {
    private val det = ShowerDetector(c)
    private val hold = Hold()
    override val back = false
    override fun title() = "샤워 인증"
    override fun step(bmp: Bitmap): String? {
        val msg = det.check(bmp)
        val t = hold.ms(msg == null)
        return if (t >= 2000) null else msg ?: "확인 중… ${t / 1000}초"
    }
}

/** 알라미 AI 미션 방식: 목록에서 무작위로 고른 물건이 1초 연속 인식되면 완료. skip()으로 다른 물건으로 교체 */
class ObjectMission(private val pool: List<String>) : Mission {
    private val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    private val hold = Hold()
    @Volatile private var target = pool.random()
    fun skip() { if (pool.size > 1) target = (pool - target).random() }
    override val back = true
    override fun title() = "${OBJECTS[target]!!.icon} '${OBJECTS[target]!!.name}' 찾기"
    override fun step(bmp: Bitmap): String? {
        val seen = Tasks.await(labeler.process(InputImage.fromBitmap(bmp, 0))).any { it.text == target }
        val t = hold.ms(seen)
        return if (t >= 1000) null else if (seen) "인식 중…" else "${OBJECTS[target]!!.name}을(를) 카메라에 비춰 주세요"
    }
}

/**
 * 푸시업 goal회 인식되면 완료. 세 방식 공통 부분:
 * - 반복 세기: 내려감 조건을 넘으면 진입, 올라옴 조건을 넘으면 1회 (ML Kit RepetitionCounter의 진입/이탈 임계값 방식)
 * - 꼼수 방지: 가속도 센서로 폰 자세(바닥 방식은 화면이 위로 눕힘, 정면 방식은 세움)와 흔들림을 확인,
 *   어긋나면 기준값과 진행 중 동작을 초기화하고 세지 않음
 * 각 방식의 임계값은 근거 문헌 없는 초기값이라 실사용으로 조정 필요
 */
abstract class PushupBase(c: Context, private val goal: Int, private val upright: Boolean) : Mission, SensorEventListener {
    private var down = false
    private var reps = 0
    private val sm = c.getSystemService(SensorManager::class.java)
    @Volatile private var posOk = false
    @Volatile private var lastMove = 0L

    init { sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME) }

    override fun onSensorChanged(e: SensorEvent) {
        val (x, y, z) = e.values
        if (abs(sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH) > MOVE) lastMove = SystemClock.elapsedRealtime()
        posOk = if (upright) abs(z) < UPRIGHT else z > FLAT
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun close() = sm.unregisterListener(this)
    override val back = false
    override fun title() = "푸시업 $reps/$goal"

    /** 기준값 초기화 */
    protected abstract fun reset()

    /** 프레임에서 몸을 못 찾으면 안내 문구, 찾으면 count()를 호출하고 null */
    protected abstract fun track(bmp: Bitmap): String?

    protected fun count(isDown: Boolean, isUp: Boolean) {
        if (!down) down = isDown else if (isUp) { reps++; down = false }
    }

    override fun step(bmp: Bitmap): String? {
        val problem = if (!posOk) (if (upright) "폰을 내 앞 바닥에 세워 두세요" else "폰을 화면이 위로 오게 바닥에 놓아 주세요")
        else if (SystemClock.elapsedRealtime() - lastMove < STILL_MS) "폰이 움직였어요. 가만히 두세요" else null
        if (problem != null) { reset(); down = false; return "$problem ($reps/$goal)" }
        track(bmp)?.let { return "$it ($reps/$goal)" }
        if (reps >= goal) { close(); return null }
        return "푸시업 $reps/$goal"
    }

    companion object {
        const val MOVE = 1.0f      // 중력과의 가속도 차이(m/s²)가 이보다 크면 움직임으로 판단
        const val STILL_MS = 1000L // 마지막 움직임 후 이 시간이 지나야 다시 셈
        const val FLAT = 8.5f      // 눕힘: 화면이 위를 향할 때 z축 가속도 하한 (약 30° 이내)
        const val UPRIGHT = 4.0f   // 세움: z축 가속도 상한 (화면이 거의 수직)
    }
}

/**
 * 바닥 방식: 폰을 얼굴 아래 바닥에 두고 얼굴 크기로 셈 (PushFit Pro 등의 얼굴 추적 방식).
 * 얼굴 폭/화면 폭이 가장 작을 때(팔 편 상태) 기준 1.6배 이상 → 내려감, 1.25배 이하 → 올라옴
 */
class FloorPushup(c: Context, goal: Int) : PushupBase(c, goal, upright = false) {
    private val faces = FaceDetection.getClient(FaceDetectorOptions.Builder().build())
    private var base = Float.MAX_VALUE
    override fun reset() { base = Float.MAX_VALUE }
    override fun track(bmp: Bitmap): String? {
        val f = Tasks.await(faces.process(InputImage.fromBitmap(bmp, 0))).maxByOrNull { it.boundingBox.width() }
            ?: return "폰을 얼굴 아래 바닥에 두고 화면을 보며 푸시업 해 주세요"
        val r = f.boundingBox.width().toFloat() / bmp.width
        base = minOf(base, r)
        count(r >= base * 1.6f, r <= base * 1.25f)
        return null
    }
}

/**
 * 정면·어깨 방식: 폰을 앞에 세워 두고 (손목 y − 어깨 y) / 어깨 너비로 셈. 손목은 바닥에 고정이라 어깨가 내려오면 값이 작아짐.
 * 가장 클 때(팔 편 상태) 기준 0.5배 이하 → 내려감, 0.8배 이상 → 올라옴
 */
class ShoulderPushup(c: Context, goal: Int) : PushupBase(c, goal, upright = true) {
    private val pose = PoseDetection.getClient(PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build())
    private var base = 0f
    override fun reset() { base = 0f }
    override fun track(bmp: Bitmap): String? {
        val p = Tasks.await(pose.process(InputImage.fromBitmap(bmp, 0)))
        val lm = listOf(PoseLandmark.LEFT_SHOULDER, PoseLandmark.RIGHT_SHOULDER, PoseLandmark.LEFT_WRIST, PoseLandmark.RIGHT_WRIST)
            .map { p.getPoseLandmark(it) }
        if (lm.any { it == null || it.inFrameLikelihood < 0.5f }) return "어깨와 손목이 보이게 폰을 정면에 세워 주세요"
        val (ls, rs, lw, rw) = lm.map { it!!.position }
        val width = hypot(ls.x - rs.x, ls.y - rs.y)
        val d = ((lw.y + rw.y) / 2 - (ls.y + rs.y) / 2) / width
        base = maxOf(base, d)
        count(d <= base * 0.5f, d >= base * 0.8f)
        return null
    }
}

/**
 * 정면·얼굴 방식: 폰을 앞에 세워 두고 화면 속 얼굴 높이로 셈.
 * 얼굴이 가장 위에 있을 때(팔 편 상태) 기준, 얼굴 높이의 1.0배 이상 내려가면 → 내려감, 0.4배 이내로 돌아오면 → 올라옴
 */
class FacePushup(c: Context, goal: Int) : PushupBase(c, goal, upright = true) {
    private val faces = FaceDetection.getClient(FaceDetectorOptions.Builder().build())
    private var base = Float.MAX_VALUE
    override fun reset() { base = Float.MAX_VALUE }
    override fun track(bmp: Bitmap): String? {
        val f = Tasks.await(faces.process(InputImage.fromBitmap(bmp, 0))).maxByOrNull { it.boundingBox.width() }
            ?: return "얼굴이 보이게 폰을 정면 바닥에 세워 주세요"
        val y = f.boundingBox.exactCenterY() / bmp.height
        val h = f.boundingBox.height().toFloat() / bmp.height
        base = minOf(base, y)
        count(y - base >= h * 1.0f, y - base <= h * 0.4f)
        return null
    }
}
