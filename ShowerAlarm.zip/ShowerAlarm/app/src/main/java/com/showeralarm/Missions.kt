package com.showeralarm

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlin.math.abs
import kotlin.math.hypot

/** 미션 키: "shower", "object", "pushup:횟수" */
val MISSIONS = linkedMapOf("shower" to "샤워 인증", "object" to "물건 찾기", "pushup" to "푸시업")

fun missionName(key: String) =
    if (key.startsWith("pushup:")) "푸시업 ${key.substringAfter(":")}개" else MISSIONS[key]!!

class Obj(val label: String, val name: String, val icon: String)

/** 물건 찾기 후보: ML Kit 이미지 라벨링 기본 모델의 라벨을 알라미처럼 장소·종류별로 분류 */
val CATEGORIES = linkedMapOf(
    "화장실" to listOf(Obj("Sink", "세면대", "🚰"), Obj("Tile", "타일", "🔲")),
    "거실" to listOf(
        Obj("Couch", "소파", "🛋️"), Obj("Cushion", "쿠션", "🟨"), Obj("Clock", "시계", "⏰"),
        Obj("Television", "TV", "📺"), Obj("Piano", "피아노", "🎹"), Obj("Musical instrument", "악기", "🎸"),
        Obj("Lampshade", "전등갓", "💡")
    ),
    "식물" to listOf(Obj("Flowerpot", "화분", "🪴"), Obj("Plant", "식물", "🌿"), Obj("Flower", "꽃", "🌷")),
    "내 소지품" to listOf(
        Obj("Glasses", "안경", "👓"), Obj("Sunglasses", "선글라스", "🕶️"), Obj("Bag", "가방", "🎒"),
        Obj("Handbag", "핸드백", "👜"), Obj("Cap", "모자", "🧢"), Obj("Mobile phone", "휴대폰", "📱"),
        Obj("Lipstick", "립스틱", "💄"), Obj("Ring", "반지", "💍"), Obj("Money", "돈", "💵")
    ),
    "내 방" to listOf(
        Obj("Drawer", "서랍", "🗄️"), Obj("Curtain", "커튼", "🪟"), Obj("Desk", "책상", "🪵"),
        Obj("Pillow", "베개", "🛏️"), Obj("Chair", "의자", "🪑"), Obj("Stuffed toy", "봉제 인형", "🧸"),
        Obj("Cabinetry", "수납장", "🚪"), Obj("Shelf", "선반", "📚"), Obj("Computer", "컴퓨터", "💻"),
        Obj("Jeans", "청바지", "👖"), Obj("Jacket", "재킷", "🧥"), Obj("Poster", "포스터", "🖼️")
    ),
    "주방" to listOf(
        Obj("Cup", "컵", "🥛"), Obj("Tableware", "식기", "🍽️"), Obj("Cutlery", "수저·포크", "🍴"),
        Obj("Cookware and bakeware", "조리기구", "🍳"), Obj("Fruit", "과일", "🍎"), Obj("Vegetable", "채소", "🥦"),
        Obj("Bread", "빵", "🍞"), Obj("Juice", "주스", "🧃"), Obj("Cola", "콜라", "🥤"), Obj("Coffee", "커피", "☕")
    ),
    "사람" to listOf(
        Obj("Hand", "손", "✋"), Obj("Foot", "발", "🦶"), Obj("Ear", "귀", "👂"), Obj("Mouth", "입", "👄"),
        Obj("Smile", "미소", "😊"), Obj("Nail", "손톱", "💅"), Obj("Hair", "머리카락", "💇"), Obj("Beard", "수염", "🧔"),
        Obj("Muscle", "근육", "💪")
    ),
    "현관" to listOf(
        Obj("Shoe", "신발", "👞"), Obj("Sneakers", "운동화", "👟"), Obj("Umbrella", "우산", "☂️"),
        Obj("Stairs", "계단", "🪜"), Obj("Bicycle", "자전거", "🚲"), Obj("Helmet", "헬멧", "⛑️")
    ),
    "동물" to listOf(Obj("Dog", "개", "🐶"), Obj("Cat", "고양이", "🐱"), Obj("Pet", "반려동물", "🐾"))
)

/** 라벨 → 물건 */
val OBJECTS = CATEGORIES.values.flatten().associateBy { it.label }

/** 해제 미션. step()은 카메라 프레임마다 호출되며 안내 문구를 반환, 완료되면 null */
interface Mission {
    val back: Boolean // 후면 카메라 사용 여부
    fun title(): String
    fun step(bmp: Bitmap): String?
}

/** 조건이 연속으로 유지된 시간(ms). 끊기면 -1 */
private class Hold {
    private var since = 0L
    fun ms(ok: Boolean): Long {
        val now = System.currentTimeMillis()
        since = if (!ok) 0L else if (since == 0L) now else since
        return if (ok) now - since else -1
    }
}

/** 전신·직립·옷 없음이 2초 연속 확인되면 완료 */
class ShowerMission(c: Context) : Mission {
    private val det = ShowerDetector(c)
    private val hold = Hold()
    override val back = false
    override fun title() = "샤워 인증"
    override fun step(bmp: Bitmap): String? {
        val msg = det.check(bmp)
        val t = hold.ms(msg == null)
        return if (t >= 2000) null else msg ?: "확인 중… ${t / 1000}초"
    }
}

/** 알라미 AI 미션 방식: 목록에서 무작위로 고른 물건이 1초 연속 인식되면 완료. skip()으로 다른 물건으로 교체 */
class ObjectMission(private val pool: List<String>) : Mission {
    private val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    private val hold = Hold()
    @Volatile private var target = pool.random()
    fun skip() { if (pool.size > 1) target = (pool - target).random() }
    override val back = true
    override fun title() = "${OBJECTS[target]!!.icon} '${OBJECTS[target]!!.name}' 찾기"
    override fun step(bmp: Bitmap): String? {
        val seen = Tasks.await(labeler.process(InputImage.fromBitmap(bmp, 0))).any { it.text == target }
        val t = hold.ms(seen)
        return if (t >= 1000) null else if (seen) "인식 중…" else "${OBJECTS[target]!!.name}을(를) 카메라에 비춰 주세요"
    }
}

/**
 * 푸시업 goal회 인식되면 완료.
 * Google ML Kit vision-quickstart의 pose classification(k-NN) · EMASmoothing · RepetitionCounter와
 * 동봉 샘플(fitness_pose_samples.csv)을 Kotlin으로 옮김 (Apache-2.0). 파라미터는 원본 기본값 그대로.
 */
class PushupMission(c: Context, private val goal: Int) : Mission {
    private data class P(val x: Float, val y: Float, val z: Float) {
        operator fun minus(o: P) = P(x - o.x, y - o.y, z - o.z)
        operator fun plus(o: P) = P(x + o.x, y + o.y, z + o.z)
        operator fun times(k: Float) = P(x * k, y * k, z * k)
        fun w() = P(x, y, z * 0.2f) // AXES_WEIGHTS (1, 1, 0.2)
        fun maxAbs() = maxOf(abs(x), abs(y), abs(z))
        fun sumAbs() = abs(x) + abs(y) + abs(z)
        fun norm2d() = hypot(x, y)
    }

    private class Sample(val cls: String, val e: List<P>)

    private val pose = PoseDetection.getClient(PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build())
    private val samples = c.assets.open("pose/fitness_pose_samples.csv").bufferedReader().readLines().map { line ->
        val t = line.split(",")
        Sample(t[1], embed((2 until t.size step 3).map { P(t[it].toFloat(), t[it + 1].toFloat(), t[it + 2].toFloat()) }))
    }
    private val window = ArrayDeque<Map<String, Float>>()
    private var lastMs = 0L
    private var entered = false
    private var reps = 0

    override val back = false
    override fun title() = "푸시업 $reps/$goal"

    override fun step(bmp: Bitmap): String? {
        val lm = Tasks.await(pose.process(InputImage.fromBitmap(bmp, 0))).allPoseLandmarks
        if (lm.isEmpty()) return "옆에서 전신이 보이게 폰을 두고 푸시업 해 주세요"
        val conf = smooth(classify(lm.map { P(it.position3D.x, it.position3D.y, it.position3D.z) }))["pushups_down"] ?: 0f
        if (!entered) entered = conf > ENTER else if (conf < EXIT) { reps++; entered = false }
        return if (reps >= goal) null else "푸시업 $reps/$goal"
    }

    private fun avg(a: P, b: P) = (a + b) * 0.5f

    // PoseEmbedding: 골반 중심 기준 정규화 후 관절 쌍 차이 벡터
    private fun embed(raw: List<P>): List<P> {
        val center = avg(raw[23], raw[24])
        val c = raw.map { it - center }
        val hips = avg(c[23], c[24])
        val size = maxOf((hips - avg(c[11], c[12])).norm2d() * 2.5f, c.maxOf { (it - hips).norm2d() })
        val lm = c.map { it * (100f / size) }
        fun d(a: Int, b: Int) = lm[b] - lm[a]
        return listOf(avg(lm[11], lm[12]) - avg(lm[23], lm[24])) + listOf(
            11 to 13, 12 to 14, 13 to 15, 14 to 16, 23 to 25, 24 to 26, 25 to 27, 26 to 28,
            11 to 15, 12 to 16, 23 to 27, 24 to 28, 23 to 15, 24 to 16, 11 to 27, 12 to 28,
            23 to 15, 24 to 16, 13 to 14, 25 to 26, 15 to 16, 27 to 28
        ).map { (a, b) -> d(a, b) }
    }

    // PoseClassifier: 최대 거리 상위 30 → 평균 거리 상위 10의 클래스 개수 (좌우 반전 포함)
    private fun classify(lm: List<P>): Map<String, Float> {
        val e = embed(lm)
        val f = embed(lm.map { P(-it.x, it.y, it.z) })
        val top30 = samples.map { s ->
            s to minOf(e.indices.maxOf { (e[it] - s.e[it]).w().maxAbs() }, e.indices.maxOf { (f[it] - s.e[it]).w().maxAbs() })
        }.sortedBy { it.second }.take(30)
        val top10 = top30.map { (s, _) ->
            s to minOf(e.indices.map { (e[it] - s.e[it]).w().sumAbs() }.sum(), e.indices.map { (f[it] - s.e[it]).w().sumAbs() }.sum())
        }.sortedBy { it.second }.take(10)
        return top10.groupingBy { it.first.cls }.eachCount().mapValues { it.value.toFloat() }
    }

    // EMASmoothing: window 10, alpha 0.2, 100ms 이상 끊기면 초기화
    private fun smooth(r: Map<String, Float>): Map<String, Float> {
        val now = SystemClock.elapsedRealtime()
        if (now - lastMs > 100) window.clear()
        lastMs = now
        if (window.size == 10) window.removeLast()
        window.addFirst(r)
        return window.flatMap { it.keys }.toSet().associateWith { cls ->
            var k = 1f; var top = 0f; var bottom = 0f
            for (w in window) { top += k * (w[cls] ?: 0f); bottom += k; k *= 0.8f }
            top / bottom
        }
    }

    companion object {
        const val ENTER = 6f // RepetitionCounter 기본값
        const val EXIT = 4f
    }
}
