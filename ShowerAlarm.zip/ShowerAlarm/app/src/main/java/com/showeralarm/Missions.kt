package com.showeralarm

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlin.math.abs
import kotlin.math.hypot

val MISSIONS = linkedMapOf("shower" to "샤워 인증", "object" to "물건 찾기", "pushup" to "푸시업 ${PushupMission.GOAL}개")

/** 물건 찾기 후보: ML Kit 이미지 라벨링 기본 모델의 라벨 중 집에 흔한 물건 (라벨 → 한글 이름) */
val OBJECTS = linkedMapOf(
    "Cup" to "컵", "Chair" to "의자", "Clock" to "시계", "Desk" to "책상", "Couch" to "소파", "Pillow" to "베개",
    "Cushion" to "쿠션", "Curtain" to "커튼", "Television" to "TV", "Computer" to "컴퓨터", "Shoe" to "신발",
    "Sneakers" to "운동화", "Bag" to "가방", "Handbag" to "핸드백", "Umbrella" to "우산", "Glasses" to "안경",
    "Sunglasses" to "선글라스", "Hat" to "모자", "Cap" to "야구모자", "Jacket" to "재킷", "Jeans" to "청바지",
    "Lampshade" to "전등갓", "Flowerpot" to "화분", "Plant" to "식물", "Drawer" to "서랍", "Shelf" to "선반",
    "Cabinetry" to "수납장", "Sink" to "싱크대·세면대", "Cutlery" to "수저·포크", "Tableware" to "식기",
    "Cookware and bakeware" to "냄비·프라이팬", "Stuffed toy" to "인형", "Cat" to "고양이", "Dog" to "강아지"
)

/** 해제 미션. step()은 카메라 프레임마다 호출되며 안내 문구를 반환, 완료되면 null */
interface Mission {
    val back: Boolean // 후면 카메라 사용 여부
    fun title(): String
    fun step(bmp: Bitmap): String?
}

/** 조건이 연속으로 유지된 시간(ms). 끊기면 -1 */
private class Hold {
    private var since = 0L
    fun ms(ok: Boolean): Long {
        val now = System.currentTimeMillis()
        since = if (!ok) 0L else if (since == 0L) now else since
        return if (ok) now - since else -1
    }
}

/** 전신·직립·옷 없음이 2초 연속 확인되면 완료 */
class ShowerMission(c: Context) : Mission {
    private val det = ShowerDetector(c)
    private val hold = Hold()
    override val back = false
    override fun title() = "샤워 인증"
    override fun step(bmp: Bitmap): String? {
        val msg = det.check(bmp)
        val t = hold.ms(msg == null)
        return if (t >= 2000) null else msg ?: "확인 중… ${t / 1000}초"
    }
}

/** 알라미 AI 미션 방식: 목록에서 무작위로 고른 물건이 1초 연속 인식되면 완료. skip()으로 다른 물건으로 교체 */
class ObjectMission(private val pool: List<String>) : Mission {
    private val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    private val hold = Hold()
    @Volatile private var target = pool.random()
    fun skip() { if (pool.size > 1) target = (pool - target).random() }
    override val back = true
    override fun title() = "'${OBJECTS[target]}' 찾기"
    override fun step(bmp: Bitmap): String? {
        val seen = Tasks.await(labeler.process(InputImage.fromBitmap(bmp, 0))).any { it.text == target }
        val t = hold.ms(seen)
        return if (t >= 1000) null else if (seen) "인식 중…" else "${OBJECTS[target]}을(를) 카메라에 비춰 주세요"
    }
}

/**
 * 푸시업 GOAL회 인식되면 완료.
 * Google ML Kit vision-quickstart의 pose classification(k-NN) · EMASmoothing · RepetitionCounter와
 * 동봉 샘플(fitness_pose_samples.csv)을 Kotlin으로 옮김 (Apache-2.0). 파라미터는 원본 기본값 그대로.
 */
class PushupMission(c: Context) : Mission {
    private data class P(val x: Float, val y: Float, val z: Float) {
        operator fun minus(o: P) = P(x - o.x, y - o.y, z - o.z)
        operator fun plus(o: P) = P(x + o.x, y + o.y, z + o.z)
        operator fun times(k: Float) = P(x * k, y * k, z * k)
        fun w() = P(x, y, z * 0.2f) // AXES_WEIGHTS (1, 1, 0.2)
        fun maxAbs() = maxOf(abs(x), abs(y), abs(z))
        fun sumAbs() = abs(x) + abs(y) + abs(z)
        fun norm2d() = hypot(x, y)
    }

    private class Sample(val cls: String, val e: List<P>)

    private val pose = PoseDetection.getClient(PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build())
    private val samples = c.assets.open("pose/fitness_pose_samples.csv").bufferedReader().readLines().map { line ->
        val t = line.split(",")
        Sample(t[1], embed((2 until t.size step 3).map { P(t[it].toFloat(), t[it + 1].toFloat(), t[it + 2].toFloat()) }))
    }
    private val window = ArrayDeque<Map<String, Float>>()
    private var lastMs = 0L
    private var entered = false
    private var reps = 0

    override val back = false
    override fun title() = "푸시업 $reps/$GOAL"

    override fun step(bmp: Bitmap): String? {
        val lm = Tasks.await(pose.process(InputImage.fromBitmap(bmp, 0))).allPoseLandmarks
        if (lm.isEmpty()) return "옆에서 전신이 보이게 폰을 두고 푸시업 해 주세요"
        val conf = smooth(classify(lm.map { P(it.position3D.x, it.position3D.y, it.position3D.z) }))["pushups_down"] ?: 0f
        if (!entered) entered = conf > ENTER else if (conf < EXIT) { reps++; entered = false }
        return if (reps >= GOAL) null else "푸시업 $reps/$GOAL"
    }

    private fun avg(a: P, b: P) = (a + b) * 0.5f

    // PoseEmbedding: 골반 중심 기준 정규화 후 관절 쌍 차이 벡터
    private fun embed(raw: List<P>): List<P> {
        val center = avg(raw[23], raw[24])
        val c = raw.map { it - center }
        val hips = avg(c[23], c[24])
        val size = maxOf((hips - avg(c[11], c[12])).norm2d() * 2.5f, c.maxOf { (it - hips).norm2d() })
        val lm = c.map { it * (100f / size) }
        fun d(a: Int, b: Int) = lm[b] - lm[a]
        return listOf(avg(lm[11], lm[12]) - avg(lm[23], lm[24])) + listOf(
            11 to 13, 12 to 14, 13 to 15, 14 to 16, 23 to 25, 24 to 26, 25 to 27, 26 to 28,
            11 to 15, 12 to 16, 23 to 27, 24 to 28, 23 to 15, 24 to 16, 11 to 27, 12 to 28,
            23 to 15, 24 to 16, 13 to 14, 25 to 26, 15 to 16, 27 to 28
        ).map { (a, b) -> d(a, b) }
    }

    // PoseClassifier: 최대 거리 상위 30 → 평균 거리 상위 10의 클래스 개수 (좌우 반전 포함)
    private fun classify(lm: List<P>): Map<String, Float> {
        val e = embed(lm)
        val f = embed(lm.map { P(-it.x, it.y, it.z) })
        val top30 = samples.map { s ->
            s to minOf(e.indices.maxOf { (e[it] - s.e[it]).w().maxAbs() }, e.indices.maxOf { (f[it] - s.e[it]).w().maxAbs() })
        }.sortedBy { it.second }.take(30)
        val top10 = top30.map { (s, _) ->
            s to minOf(e.indices.map { (e[it] - s.e[it]).w().sumAbs() }.sum(), e.indices.map { (f[it] - s.e[it]).w().sumAbs() }.sum())
        }.sortedBy { it.second }.take(10)
        return top10.groupingBy { it.first.cls }.eachCount().mapValues { it.value.toFloat() }
    }

    // EMASmoothing: window 10, alpha 0.2, 100ms 이상 끊기면 초기화
    private fun smooth(r: Map<String, Float>): Map<String, Float> {
        val now = SystemClock.elapsedRealtime()
        if (now - lastMs > 100) window.clear()
        lastMs = now
        if (window.size == 10) window.removeLast()
        window.addFirst(r)
        return window.flatMap { it.keys }.toSet().associateWith { cls ->
            var k = 1f; var top = 0f; var bottom = 0f
            for (w in window) { top += k * (w[cls] ?: 0f); bottom += k; k *= 0.8f }
            top / bottom
        }
    }

    companion object {
        const val GOAL = 10
        const val ENTER = 6f // RepetitionCounter 기본값
        const val EXIT = 4f
    }
}
