package com.showeralarm

import android.content.Context
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.SystemClock
import java.io.File
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

/** 미션 키: "shower", "object", "pushup:횟수" */
val MISSIONS = linkedMapOf("shower" to "샤워 인증", "object" to "물건 찾기", "pushup" to "푸시업")

fun missionName(key: String) =
    if (":" in key) "${MISSIONS[key.substringBefore(":")]} ${key.substringAfter(":")}개" else MISSIONS[key]!!

class Obj(val label: String, val name: String, val icon: String)

/** 물건 찾기 후보: ML Kit 이미지 라벨링 기본 모델의 라벨을 알라미처럼 장소·종류별로 분류 */
val CATEGORIES = linkedMapOf(
    "화장실" to listOf(Obj("Sink", "세면대", "🚰"), Obj("Tile", "타일", "🔲")),
    "거실" to listOf(
        Obj("Couch", "소파", "🛋️"), Obj("Cushion", "쿠션", "🟨"), Obj("Clock", "시계", "⏰"),
        Obj("Television", "TV", "📺"), Obj("Piano", "피아노", "🎹"), Obj("Musical instrument", "악기", "🎸"),
        Obj("Lampshade", "전등갓", "💡")
    ),
    "식물" to listOf(Obj("Flowerpot", "화분", "🪴"), Obj("Plant", "식물", "🌿"), Obj("Flower", "꽃", "🌷")),
    "내 소지품" to listOf(
        Obj("Glasses", "안경", "👓"), Obj("Sunglasses", "선글라스", "🕶️"), Obj("Bag", "가방", "🎒"),
        Obj("Handbag", "핸드백", "👜"), Obj("Cap", "모자", "🧢"), Obj("Mobile phone", "휴대폰", "📱"),
        Obj("Lipstick", "립스틱", "💄"), Obj("Ring", "반지", "💍"), Obj("Money", "돈", "💵")
    ),
    "내 방" to listOf(
        Obj("Drawer", "서랍", "🗄️"), Obj("Curtain", "커튼", "🪟"), Obj("Desk", "책상", "🪵"),
        Obj("Pillow", "베개", "🛏️"), Obj("Chair", "의자", "🪑"), Obj("Stuffed toy", "봉제 인형", "🧸"),
        Obj("Cabinetry", "수납장", "🚪"), Obj("Shelf", "선반", "📚"), Obj("Computer", "컴퓨터", "💻"),
        Obj("Jeans", "청바지", "👖"), Obj("Jacket", "재킷", "🧥"), Obj("Poster", "포스터", "🖼️")
    ),
    "주방" to listOf(
        Obj("Cup", "컵", "🥛"), Obj("Tableware", "식기", "🍽️"), Obj("Cutlery", "수저·포크", "🍴"),
        Obj("Cookware and bakeware", "조리기구", "🍳"), Obj("Fruit", "과일", "🍎"), Obj("Vegetable", "채소", "🥦"),
        Obj("Bread", "빵", "🍞"), Obj("Juice", "주스", "🧃"), Obj("Cola", "콜라", "🥤"), Obj("Coffee", "커피", "☕")
    ),
    "사람" to listOf(
        Obj("Hand", "손", "✋"), Obj("Foot", "발", "🦶"), Obj("Ear", "귀", "👂"), Obj("Mouth", "입", "👄"),
        Obj("Smile", "미소", "😊"), Obj("Nail", "손톱", "💅"), Obj("Hair", "머리카락", "💇"), Obj("Beard", "수염", "🧔"),
        Obj("Muscle", "근육", "💪")
    ),
    "현관" to listOf(
        Obj("Shoe", "신발", "👞"), Obj("Sneakers", "운동화", "👟"), Obj("Umbrella", "우산", "☂️"),
        Obj("Stairs", "계단", "🪜"), Obj("Bicycle", "자전거", "🚲"), Obj("Helmet", "헬멧", "⛑️")
    ),
    "동물" to listOf(Obj("Dog", "개", "🐶"), Obj("Cat", "고양이", "🐱"), Obj("Pet", "반려동물", "🐾"))
)

/** 라벨 → 물건 */
val OBJECTS = CATEGORIES.values.flatten().associateBy { it.label }

/** 해제 미션. step()은 카메라 프레임마다 호출되며 안내 문구를 반환, 완료되면 null */
interface Mission {
    val back: Boolean // 후면 카메라 사용 여부
    fun title(): String
    fun step(bmp: Bitmap, backCam: Boolean): String?
    fun close() {}
    /** 화면에 그릴 인식 결과 (선분 배열, 분석 이미지 좌표). 없으면 null */
    val overlay: FloatArray? get() = null
}

/** 조건이 연속으로 유지된 시간(ms). 끊기면 -1 */
private class Hold {
    private var since = 0L
    fun ms(ok: Boolean): Long {
        val now = System.currentTimeMillis()
        since = if (!ok) 0L else if (since == 0L) now else since
        return if (ok) now - since else -1
    }
}

/** 전신·직립·옷 없음이 2초 연속 확인되면 완료 */
class ShowerMission(c: Context) : Mission {
    private val det = ShowerDetector(c)
    private val hold = Hold()
    override val back = false
    override fun title() = "샤워 인증"
    override val overlay get() = det.lastPose?.let(::poseLines)
    override fun step(bmp: Bitmap, backCam: Boolean): String? {
        val msg = det.check(bmp)
        val t = hold.ms(msg == null)
        return if (t >= 2000) null else msg ?: "확인 중… ${t / 1000}초"
    }
}

/** 알라미 AI 미션 방식: 목록에서 무작위로 고른 물건이 1초 연속 인식되면 완료. skip()으로 다른 물건으로 교체 */
class ObjectMission(private val pool: List<String>) : Mission {
    private val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
    private val hold = Hold()
    @Volatile private var target = pool.random()
    fun skip() { if (pool.size > 1) target = (pool - target).random() }
    override val back = true
    override fun title() = "${OBJECTS[target]!!.icon} '${OBJECTS[target]!!.name}' 찾기"
    override fun step(bmp: Bitmap, backCam: Boolean): String? {
        val seen = Tasks.await(labeler.process(InputImage.fromBitmap(bmp, 0))).any { it.text == target }
        val t = hold.ms(seen)
        return if (t >= 1000) null else if (seen) "인식 중…" else "${OBJECTS[target]!!.name}을(를) 카메라에 비춰 주세요"
    }
}

/**
 * 푸시업 goal회 인식되면 완료. 가속도 센서로 폰 자세를 보고 방식을 자동 선택:
 * - 화면이 위로 눕혀져 있으면 바닥 방식: 폰을 얼굴 아래에 두고 얼굴 크기로 셈 (PushFit Pro 등의 얼굴 추적 방식).
 *   얼굴 폭/화면 폭이 가장 작을 때(팔 편 상태) 기준 1.6배 이상 → 내려감, 1.25배 이하 → 올라옴
 * - 세워져 있으면 정면 방식: (손목 y − 어깨 y) / 어깨 너비로 셈. 손목은 바닥에 고정이라 어깨가 내려오면 값이 작아짐.
 *   가장 클 때(팔 편 상태) 기준 0.5배 이하 → 내려감, 0.8배 이상 → 올라옴
 * 반복 세기는 ML Kit RepetitionCounter의 진입/이탈 임계값 방식. 꼼수 방지로 폰이 흔들리거나 자세가 바뀌면
 * 기준값과 진행 중 동작을 초기화하고 세지 않음. 임계값은 근거 문헌 없는 초기값이라 실사용으로 조정 필요
 */
class PushupMission(c: Context, private val goal: Int) : Mission, SensorEventListener {
    private val faces = FaceDetection.getClient(FaceDetectorOptions.Builder().build())
    private val pose = PoseDetection.getClient(PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build())
    private var base = 0f
    private var down = false
    private var reps = 0
    private var lastMode: Boolean? = null // true = 바닥, false = 정면
    // 정면 방식: 최근 어깨 너비(중앙값으로 순간 오인식 무시), 최근 판정 값(시각, 값)
    private val sws = ArrayDeque<Float>()
    private val hist = ArrayDeque<Pair<Long, Float>>()

    private val sm = c.getSystemService(SensorManager::class.java)
    @Volatile private var ax = 0f
    @Volatile private var ay = 0f
    @Volatile private var z = 0f
    private var lastRep = 0L
    @Volatile override var overlay: FloatArray? = null
    private val ctx = c
    private val tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
    @Volatile private var lastMove = 0L

    // 진단 로그: 프레임마다 판정에 쓴 숫자를 기록 (영상은 기록 안 함). 미션을 시작할 때마다 새로 씀, 설정에서 저장 가능
    private val log = File(c.filesDir, LOG_FILE).bufferedWriter().apply {
        write("t_ms,mode,z,ax,ay,still,base,down,reps,status,detail\n")
    }
    private val t0 = SystemClock.elapsedRealtime()
    private var detail = ""
    private var closed = false

    private fun rec(mode: String, status: String) {
        if (closed) return
        val still = SystemClock.elapsedRealtime() - lastMove >= STILL_MS
        log.write("${SystemClock.elapsedRealtime() - t0},$mode,%.2f,%.2f,%.2f,$still,%.4f,$down,$reps,$status,$detail\n"
            .format(z, ax, ay, base))
        log.flush()
        detail = ""
    }

    init { sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME) }

    override fun onSensorChanged(e: SensorEvent) {
        val (x, y, zz) = e.values
        if (abs(sqrt(x * x + y * y + zz * zz) - SensorManager.GRAVITY_EARTH) > MOVE) lastMove = SystemClock.elapsedRealtime()
        ax = x; ay = y; z = zz
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun close() {
        if (closed) return
        closed = true
        sm.unregisterListener(this); tone.release(); log.close()
    }
    override val back = false
    override fun title() = "푸시업 $reps/$goal"

    // 1회당 최소 MIN_REP_MS: 그보다 빠른 반복은 오작동으로 보고 세지 않음
    private fun count(isDown: Boolean, isUp: Boolean) {
        if (!down) { down = isDown; return }
        if (!isUp) return
        down = false
        val now = SystemClock.elapsedRealtime()
        if (now - lastRep >= MIN_REP_MS) {
            reps++; lastRep = now
            // 셀 때마다 '띵' (ML Kit 샘플의 반복 카운트 알림음과 같은 톤), 카메라 화면에서 켜고 끌 수 있음
            if (ctx.prefs().getBoolean("repSound", true)) tone.startTone(ToneGenerator.TONE_PROP_BEEP)
        }
    }

    override fun step(bmp: Bitmap, backCam: Boolean): String? {
        val floor = if (z > FLAT) true else if (abs(z) < UPRIGHT) false else null
        if (floor != lastMode) { lastMode = floor; base = if (floor == true) Float.MAX_VALUE else 0f; down = false; sws.clear(); hist.clear() }
        val problem = if (floor == null) "폰을 얼굴 아래 바닥에 눕히거나, 내 앞 바닥에 세워 두세요"
        else if (SystemClock.elapsedRealtime() - lastMove < STILL_MS) "폰이 움직였어요. 가만히 두세요" else null
        val mode = when (floor) { true -> "floor"; false -> "front"; null -> "tilted" }
        if (problem != null) {
            overlay = null
            if (floor != null) { base = if (floor) Float.MAX_VALUE else 0f; down = false; sws.clear(); hist.clear() }
            rec(mode, if (floor == null) "tilted" else "moving")
            return "$problem ($reps/$goal)"
        }
        (if (floor == true) floorTrack(bmp) else frontTrack(bmp, backCam))?.let { rec(mode, "notfound"); return "$it ($reps/$goal)" }
        rec(mode, "ok")
        if (reps >= goal) { close(); return null }
        return "푸시업 $reps/$goal" + if (floor == true) " · 바닥" else " · 정면"
    }

    private fun floorTrack(bmp: Bitmap): String? {
        val f = Tasks.await(faces.process(InputImage.fromBitmap(bmp, 0))).maxByOrNull { it.boundingBox.width() }
        overlay = f?.let { rectLines(it.boundingBox) }
        f ?: return "얼굴이 보이게 폰을 얼굴 아래에 두세요"
        val r = f.boundingBox.width().toFloat() / bmp.width
        base = minOf(base, r)
        detail = "img=${bmp.width}x${bmp.height} r=%.4f isDown=${r >= base * 1.6f} isUp=${r <= base * 1.25f}".format(r)
        count(r >= base * 1.6f, r <= base * 1.25f)
        return null
    }

    /**
     * 화면 세로 방향이 아니라 실제 중력 방향으로 '어깨→손목' 높이를 잼 (폰을 가로로 세워도 동작).
     * 판정 값 d = 높이 / 어깨 너비(최근 SW_FRAMES프레임 중앙값: 바닥 자세에서 어깨가 순간적으로 한 점으로 잡히는 오인식 무시).
     * 기준(팔 편 상태) = 최근 BASE_MS 동안 d의 최댓값, d ≤ 기준×DOWN → 내려감, d ≥ 기준×UP → 올라옴.
     * 값은 실제 푸시업 10회 진단 로그로 맞춤 (주변 값 0.7~0.8 / 0.88~0.92에서도 10회로 동일)
     * 알람 화면은 세로 고정이라 영상 좌표 = 기기 좌표(x 오른쪽, y 아래). 가속도 (ax, ay)는 위쪽을 가리키므로
     * 영상 속 아래 방향은 후면 카메라 (−ax, ay), 전면 카메라는 좌우가 반대라 (ax, ay)
     */
    private fun frontTrack(bmp: Bitmap, backCam: Boolean): String? {
        val p = Tasks.await(pose.process(InputImage.fromBitmap(bmp, 0)))
        overlay = poseLines(p)
        val lm = listOf(PoseLandmark.LEFT_SHOULDER, PoseLandmark.RIGHT_SHOULDER, PoseLandmark.LEFT_WRIST, PoseLandmark.RIGHT_WRIST)
            .map { p.getPoseLandmark(it) }
        detail = "img=${bmp.width}x${bmp.height} back=$backCam like=" +
                lm.joinToString("/") { "%.2f".format(it?.inFrameLikelihood ?: -1f) }
        if (lm.any { it == null || it.inFrameLikelihood < 0.5f }) return "어깨와 손목이 보이게 폰을 정면에 세워 주세요"
        val (ls, rs, lw, rw) = lm.map { it!!.position }
        val gx = if (backCam) -ax else ax
        val gap = (((lw.x + rw.x) - (ls.x + rs.x)) / 2 * gx + ((lw.y + rw.y) - (ls.y + rs.y)) / 2 * ay) / hypot(gx, ay)
        val sw = hypot(ls.x - rs.x, ls.y - rs.y)
        sws.addLast(sw); if (sws.size > SW_FRAMES) sws.removeFirst()
        val d = gap / sws.sorted()[sws.size / 2]
        val now = SystemClock.elapsedRealtime()
        hist.addLast(now to d)
        while (now - hist.first().first > BASE_MS) hist.removeFirst()
        base = hist.maxOf { it.second }
        detail += " ls=%.0f:%.0f rs=%.0f:%.0f lw=%.0f:%.0f rw=%.0f:%.0f sw=%.1f d=%.4f isDown=${d <= base * DOWN} isUp=${d >= base * UP}"
            .format(ls.x, ls.y, rs.x, rs.y, lw.x, lw.y, rw.x, rw.y, sw, d)
        count(d <= base * DOWN, d >= base * UP)
        return null
    }

    companion object {
        const val MOVE = 1.0f      // 중력과의 가속도 차이(m/s²)가 이보다 크면 움직임으로 판단
        const val STILL_MS = 1000L // 마지막 움직임 후 이 시간이 지나야 다시 셈
        const val FLAT = 8.5f      // 눕힘: 화면이 위를 향할 때 z축 가속도 하한 (약 30° 이내)
        const val UPRIGHT = 4.0f   // 세움: z축 가속도 상한 (화면이 거의 수직)
        const val MIN_REP_MS = 500L // 1회당 최소 시간
        const val SW_FRAMES = 15    // 정면: 어깨 너비 중앙값에 쓰는 프레임 수
        const val BASE_MS = 3000L   // 정면: 기준값(최댓값)을 보는 기간
        const val DOWN = 0.75f      // 정면: 내려감 비율
        const val UP = 0.9f         // 정면: 올라옴 비율
        const val LOG_FILE = "pushup_log.csv"
    }
}
