package com.showeralarm

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.View
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseLandmark.*

// 스켈레톤 연결선 (ML Kit 포즈 랜드마크 번호): 어깨·팔·몸통·다리
private val BONES = listOf(
    LEFT_SHOULDER to RIGHT_SHOULDER, LEFT_SHOULDER to LEFT_ELBOW, LEFT_ELBOW to LEFT_WRIST,
    RIGHT_SHOULDER to RIGHT_ELBOW, RIGHT_ELBOW to RIGHT_WRIST, LEFT_SHOULDER to LEFT_HIP, RIGHT_SHOULDER to RIGHT_HIP,
    LEFT_HIP to RIGHT_HIP, LEFT_HIP to LEFT_KNEE, LEFT_KNEE to LEFT_ANKLE, RIGHT_HIP to RIGHT_KNEE, RIGHT_KNEE to RIGHT_ANKLE
)

/** 포즈 결과를 선분 배열(x1, y1, x2, y2, …, 분석 이미지 좌표)로. 화면 안에 있을 확률이 낮은 관절은 제외 */
fun poseLines(p: Pose): FloatArray = BONES.mapNotNull { (a, b) ->
    val pa = p.getPoseLandmark(a); val pb = p.getPoseLandmark(b)
    if (pa == null || pb == null || pa.inFrameLikelihood < 0.5f || pb.inFrameLikelihood < 0.5f) null
    else listOf(pa.position.x, pa.position.y, pb.position.x, pb.position.y)
}.flatten().toFloatArray()

/** 사각형(얼굴 영역)을 선분 배열로 */
fun rectLines(r: Rect): FloatArray {
    val (l, t, rr, b) = listOf(r.left, r.top, r.right, r.bottom).map { it.toFloat() }
    return floatArrayOf(l, t, rr, t, rr, t, rr, b, rr, b, l, b, l, b, l, t)
}

/**
 * 카메라 미리보기 위에 인식 결과를 그림. PreviewView 기본 배율(FILL_CENTER)과 같게 이미지 좌표를 화면에 맞추고,
 * 전면 카메라 미리보기는 거울처럼 좌우 반전되어 보이므로 x도 반전
 */
class OverlayView(c: Context) : View(c) {
    private var lines: FloatArray? = null
    private var iw = 1; private var ih = 1; private var mirror = false
    private val paint = Paint().apply { color = Color.GREEN; strokeWidth = 8f; strokeCap = Paint.Cap.ROUND }

    fun set(l: FloatArray?, w: Int, h: Int, mirror: Boolean) {
        lines = l; iw = w; ih = h; this.mirror = mirror
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val l = lines ?: return
        val s = maxOf(width.toFloat() / iw, height.toFloat() / ih)
        val dx = (width - iw * s) / 2; val dy = (height - ih * s) / 2
        val pts = FloatArray(l.size) { i ->
            if (i % 2 == 0) (l[i] * s + dx).let { if (mirror) width - it else it } else l[i] * s + dy
        }
        c.drawLines(pts, paint)
        for (i in pts.indices step 2) c.drawCircle(pts[i], pts[i + 1], 10f, paint)
    }
}
