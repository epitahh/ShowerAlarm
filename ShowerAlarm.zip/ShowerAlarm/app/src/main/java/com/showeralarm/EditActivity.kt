package com.showeralarm

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Calendar

/** 알람 추가·수정 화면 (intent extra "id" 가 있으면 수정). 모든 항목을 한 화면에서 설정 */
class EditActivity : ComponentActivity() {
    private var date = ""
    private var sound = ""
    private lateinit var ml: MissionList
    private lateinit var summary: TextView
    private lateinit var soundText: TextView
    private lateinit var holiday: Switch
    private lateinit var dayBtns: List<ToggleButton>
    private lateinit var previewBtn: Button
    private var preview: MediaPlayer? = null
    private var savedVol = -1

    // 고른 파일은 재부팅 후에도 읽을 수 있도록 영구 읽기 권한을 받아 둠
    private val pickSound = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            stopPreview()
            sound = uri.toString()
            soundText.text = "알람음: 파일"
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val editing = loadAlarms().find { it.id == intent.getIntExtra("id", -1) }

        val byTime = RadioButton(this).apply { text = "특정 시각"; id = View.generateViewId(); isChecked = true }
        val byScreen = RadioButton(this).apply { text = "화면 끈 뒤 n시간"; id = View.generateViewId() }
        val hp = NumberPicker(this).apply { minValue = 0; maxValue = 23; value = 7; setFormatter { "%02d".format(it) } }
        val mp = NumberPicker(this).apply { minValue = 0; maxValue = 59; setFormatter { "%02d".format(it) } }
        val unitH = label(":")
        val unitM = label("")
        // '화면 끈 뒤' 알람: 울리는 시각이 이 구간 안일 때만 울림
        var win: Pair<Int, Int>? = null
        val winSwitch = Switch(this).apply { text = "울리는 시각 제한" }
        val winBtn = Button(this)
        fun hm(m: Int) = "%02d:%02d".format(m / 60, m % 60)
        fun showWin() { winBtn.text = win?.let { "${hm(it.first)} ~ ${hm(it.second)}" } ?: "구간 선택"; winBtn.isEnabled = winSwitch.isChecked }
        winBtn.setOnClickListener {
            val w = win ?: (5 * 60 to 9 * 60)
            TimePickerDialog(this, { _, h1, m1 ->
                TimePickerDialog(this, { _, h2, m2 -> win = (h1 * 60 + m1) to (h2 * 60 + m2); showWin() }, w.second / 60, w.second % 60, true)
                    .apply { setTitle("끝 시각") }.show()
            }, w.first / 60, w.first % 60, true).apply { setTitle("시작 시각") }.show()
        }
        winSwitch.setOnCheckedChangeListener { _, on -> if (on && win == null) win = 5 * 60 to 9 * 60; showWin() }
        val winRow = row(winSwitch.weighted(), winBtn).apply { visibility = View.GONE }
        val type = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            addView(byTime); addView(byScreen)
            setOnCheckedChangeListener { _, id ->
                val screen = id == byScreen.id
                hp.maxValue = if (screen) 99 else 23
                unitH.text = if (screen) "시간" else ":"
                unitM.text = if (screen) "분" else ""
                winRow.visibility = if (screen) View.VISIBLE else View.GONE
            }
        }

        summary = label("")
        val dateBtn = Button(this).apply {
            text = "날짜"
            setOnClickListener {
                val c = Calendar.getInstance()
                DatePickerDialog(this@EditActivity, { _, y, mo, d ->
                    date = "%04d-%02d-%02d".format(y, mo + 1, d)
                    dayBtns.forEach { it.isChecked = false }
                    update()
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
                    .apply { datePicker.minDate = c.timeInMillis }.show()
            }
        }
        dayBtns = DAYS.map { d ->
            ToggleButton(this).apply {
                textOn = d; textOff = d; text = d; minWidth = 0; minimumWidth = 0
                setOnCheckedChangeListener { _, on -> if (on) date = ""; update() }
            }
        }
        holiday = Switch(this).apply { text = "공휴일에는 끄기"; isEnabled = false }

        val ramp = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("30"); minEms = 3 }
        val volText = label("")
        val vol = SeekBar(this).apply {
            min = 5; max = 100; progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { volText.text = "최대 볼륨 $p%"; preview?.setVolume(p / 100f, p / 100f) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        volText.text = "최대 볼륨 100%"
        val vibrate = Switch(this).apply { text = "진동" }
        val name = EditText(this).apply { hint = "알람 이름 (선택)"; setSingleLine() }
        soundText = label("알람음: 기본")
        previewBtn = Button(this).apply { text = "미리듣기"; setOnClickListener { if (preview == null) startPreview(vol.progress) else stopPreview() } }

        // 수정이면 기존 값 채우기
        editing?.let { a ->
            name.setText(a.name)
            win = windowOf(a.id)
            winSwitch.isChecked = win != null
            byScreen.isChecked = a.screen
            hp.value = if (a.screen) (a.dur / 3_600_000).toInt() else a.h
            mp.value = if (a.screen) (a.dur / 60_000 % 60).toInt() else a.m
            dayBtns.forEachIndexed { i, t -> t.isChecked = ((a.days shr i) and 1) == 1 }
            date = a.date
            holiday.isChecked = a.skipHoliday
            ramp.setText((a.ramp / 1000).toString())
            vol.progress = a.maxVol
            vibrate.isChecked = a.vibrate
            sound = a.sound
            soundText.text = if (a.sound.isEmpty()) "알람음: 기본" else "알람음: 파일"
        }

        showWin()

        // 해제 미션 (새 알람은 샤워 인증 1개, 물건 후보 0개로 시작)
        ml = MissionList(this, editing?.missions ?: listOf("shower"), editing?.objects ?: emptyList())

        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                addView(name)
                addView(type)
                addView(row(hp, unitH, mp, unitM).apply { gravity = Gravity.CENTER })
                addView(winRow)
                addView(row(summary.weighted(), dateBtn))
                addView(row(*dayBtns.map { it.weighted() }.toTypedArray()))
                addView(holiday)
                addView(row(label("소리가 최대가 될 때까지(초)").weighted(), ramp))
                addView(volText)
                addView(vol)
                addView(vibrate)
                addView(row(soundText.weighted(),
                    Button(context).apply { text = "기본"; setOnClickListener { stopPreview(); sound = ""; soundText.text = "알람음: 기본" } },
                    Button(context).apply { text = "파일 선택"; setOnClickListener { pickSound.launch(arrayOf("audio/*")) } },
                    previewBtn
                ))
                addView(label("해제 미션 (위에서부터 순서대로)"))
                addView(ml.view)
                addView(row(
                    Button(context).apply { text = "취소"; setOnClickListener { finish() } }.weighted(),
                    Button(context).apply {
                        text = "저장"
                        setOnClickListener {
                            save(editing, name.text.toString().trim(), byScreen.isChecked, hp.value, mp.value,
                                if (byScreen.isChecked && winSwitch.isChecked) win else null,
                                (ramp.text.toString().toLongOrNull() ?: 0) * 1000, vol.progress, vibrate.isChecked)
                        }
                    }.weighted()
                ))
                if (editing != null) addView(Button(context).apply {
                    text = "삭제"
                    setOnClickListener {
                        AlertDialog.Builder(this@EditActivity).setMessage("이 알람을 삭제할까요?")
                            .setPositiveButton("삭제") { _, _ ->
                                val l = loadAlarms()
                                disarm(l.first { it.id == editing.id })
                                l.removeAll { it.id == editing.id }
                                sync(l)
                                finish()
                            }.setNegativeButton("취소", null).show()
                    }
                })
            })
        })
        update()
    }

    /** 실제 알람과 같게: 알람 볼륨을 최대로 두고 알람음을 최대 볼륨(%)으로 반복 재생. 멈추면 원래 알람 볼륨으로 복구 */
    private fun startPreview(maxVol: Int) {
        val am = getSystemService(AudioManager::class.java)
        savedVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        preview = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            setDataSource(this@EditActivity, if (sound.isEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) else Uri.parse(sound))
            isLooping = true
            setVolume(maxVol / 100f, maxVol / 100f)
            prepare()
            start()
        }
        previewBtn.text = "정지"
    }

    private fun stopPreview() {
        preview?.release() ?: return
        preview = null
        getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, savedVol, 0)
        previewBtn.text = "미리듣기"
    }

    override fun onPause() {
        super.onPause()
        stopPreview()
    }

    /** 날짜·요일 선택 상태를 요약 문구와 공휴일 스위치에 반영 */
    private fun update() {
        val days = dayBtns.filter { it.isChecked }
        holiday.isEnabled = days.isNotEmpty()
        if (days.isEmpty()) holiday.isChecked = false
        summary.text = when {
            days.isNotEmpty() -> "매주 " + days.joinToString("·") { it.textOn }
            date.isNotEmpty() -> "$date 만"
            else -> "한 번"
        }
    }

    private fun save(
        editing: Alarm?, name: String, screen: Boolean, h: Int, m: Int, window: Pair<Int, Int>?, ramp: Long, maxVol: Int, vibrate: Boolean
    ) {
        val dur = if (screen) (h * 60 + m) * 60_000L else 0L
        if (screen && dur == 0L) return toast("시간을 입력해 주세요")
        if (!ml.valid()) return
        val days = dayBtns.indices.sumOf { if (dayBtns[it].isChecked) 1 shl it else 0 }
        val l = loadAlarms()
        val a = Alarm(
            editing?.id ?: ((l.maxOfOrNull { it.id } ?: 0) + 1), name, screen, if (screen) 0 else h, if (screen) 0 else m, dur,
            days, holiday.isChecked, date, ramp, maxVol, vibrate, sound, ml.missions.toList(), ml.objects.toList(), true, 0
        )
        if (!screen && date.isNotEmpty() && nextTime(a) <= System.currentTimeMillis()) return toast("이미 지난 시각이에요")
        // 수정이면 기존 예약을 취소하고 같은 자리에 교체
        val i = l.indexOfFirst { it.id == a.id }
        if (i >= 0) { disarm(l[i]); l[i] = a } else l.add(a)
        setSkip(a.id, 0)
        setWindow(a.id, window)
        sync(l)
        finish()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun label(s: String) = TextView(this).apply { text = s; textSize = 18f; setPadding(16, 0, 16, 0) }
    private fun row(vararg v: View) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, 16, 0, 16)
        v.forEach { addView(it) }
    }
    private fun <T : View> T.weighted() = apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
}
