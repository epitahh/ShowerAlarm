package com.showeralarm

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.net.Uri
import android.os.*
import androidx.core.app.ServiceCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

fun Context.prefs(): SharedPreferences = getSharedPreferences("p", Context.MODE_PRIVATE)

val DAYS = arrayOf("일", "월", "화", "수", "목", "금", "토")

/**
 * screen=false: h:m 에 울림 / screen=true: 화면 꺼진 시각 + dur 에 울림
 * 반복 규칙: days(비트0=일 … 비트6=토, 0이면 반복 없음), skipHoliday(공휴일 제외), date("yyyy-MM-dd" 지정일, ""이면 없음)
 *   - screen 알람은 '꺼진 시각 + dur' 이 규칙에 맞을 때만 울림
 * ramp = 최대 볼륨까지 걸리는 시간(ms). maxVol = 최대 볼륨(%). vibrate = 진동 여부
 * sound = 알람음 파일 Uri(""이면 기본 알람음). at = 현재 예약 시각(0이면 없음)
 * missions = 해제 미션 순서(중복 허용, "shower" / "object" / "pushup:횟수"). objects = 물건 찾기 후보(OBJECTS 키)
 */
data class Alarm(
    val id: Int, val screen: Boolean, val h: Int, val m: Int, val dur: Long,
    val days: Int, val skipHoliday: Boolean, val date: String,
    val ramp: Long, val maxVol: Int, val vibrate: Boolean, val sound: String,
    val missions: List<String>, val objects: List<String>, var on: Boolean, var at: Long
)

private fun JSONArray.strings() = List(length()) { getString(it) }

fun Context.loadAlarms(): MutableList<Alarm> = JSONArray(prefs().getString("alarms", "[]")).let { a ->
    MutableList(a.length()) {
        a.getJSONObject(it).run {
            Alarm(
                getInt("id"), getBoolean("screen"), getInt("h"), getInt("m"), getLong("dur"),
                getInt("days"), getBoolean("skipHoliday"), getString("date"),
                getLong("ramp"), getInt("maxVol"), getBoolean("vibrate"), getString("sound"),
                getJSONArray("missions").strings(), getJSONArray("objects").strings(), getBoolean("on"), getLong("at")
            )
        }
    }
}

fun Context.saveAlarms(l: List<Alarm>) = prefs().edit().putString("alarms", JSONArray(l.map {
    JSONObject().put("id", it.id).put("screen", it.screen).put("h", it.h).put("m", it.m).put("dur", it.dur)
        .put("days", it.days).put("skipHoliday", it.skipHoliday).put("date", it.date)
        .put("ramp", it.ramp).put("maxVol", it.maxVol).put("vibrate", it.vibrate).put("sound", it.sound)
        .put("missions", JSONArray(it.missions)).put("objects", JSONArray(it.objects))
        .put("on", it.on).put("at", it.at)
}).toString()).apply()

// 빌드 시 받아 넣은 공휴일 목록 (yyyyMMdd)
private var holidays: Set<String>? = null

private fun Context.isHoliday(c: Calendar): Boolean {
    val s = holidays ?: assets.open("holidays.txt").bufferedReader().readLines().toSet().also { holidays = it }
    return "%04d%02d%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)) in s
}

/** 해당 시각이 알람의 반복 규칙(지정일·요일·공휴일 제외)에 맞는지 */
private fun Context.allowed(a: Alarm, c: Calendar) =
    (a.date.isEmpty() || a.date == "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))) &&
            (a.days == 0 || ((a.days shr (c.get(Calendar.DAY_OF_WEEK) - 1)) and 1) == 1) &&
            !(a.skipHoliday && isHoliday(c))

/** '특정 시각' 알람의 다음 울릴 시각 (지정일이면 그 날짜의 시각) */
fun Context.nextTime(a: Alarm): Long {
    val c = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, a.h); set(Calendar.MINUTE, a.m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    if (a.date.isNotEmpty()) {
        val (y, mo, d) = a.date.split("-").map { it.toInt() }
        c.set(y, mo - 1, d)
        return c.timeInMillis
    }
    while (c.timeInMillis <= System.currentTimeMillis() || !allowed(a, c)) c.add(Calendar.DATE, 1)
    return c.timeInMillis
}

private fun Context.pi(id: Int) = PendingIntent.getBroadcast(
    this, id, Intent(this, AlarmReceiver::class.java).putExtra("id", id),
    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)

fun Context.arm(a: Alarm, at: Long) {
    a.at = at
    val show = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(a.id))
}

fun Context.disarm(a: Alarm) {
    a.at = 0
    getSystemService(AlarmManager::class.java).cancel(pi(a.id))
}

/** 켜짐/꺼짐 상태에 맞춰 예약과 화면 감시 서비스를 정리하고 저장. 지난 지정일 알람은 꺼짐 처리 */
fun Context.sync(l: List<Alarm>) {
    for (a in l) {
        if (a.on && !a.screen && a.at == 0L) {
            val t = nextTime(a)
            if (t > System.currentTimeMillis()) arm(a, t) else a.on = false
        }
        if (!a.on) disarm(a)
    }
    saveAlarms(l)
    val svc = Intent(this, ScreenService::class.java)
    if (l.any { it.on && it.screen }) startForegroundService(svc) else stopService(svc)
}

fun Service.startFg(id: Int, title: String, importance: Int, fullScreen: PendingIntent? = null) {
    val ch = "c$importance"
    getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, title, importance))
    val n = Notification.Builder(this, ch)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(title)
        .setOngoing(true)
        .apply {
            fullScreen?.let {
                setCategory(Notification.CATEGORY_ALARM)
                setFullScreenIntent(it, true)
                setContentIntent(it)
            }
        }.build()
    ServiceCompat.startForeground(this, id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
}

/** 요일 반복 알람은 다음 회차로 다시 예약, 그 외(한 번·지정일)는 울린 뒤 꺼짐 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val l = c.loadAlarms()
        val a = l.first { it.id == id }.apply { at = 0; if (days == 0) on = false }
        // 이미 다른 알람이 울리는 중이면 그 알람의 커지는 시간을 유지
        if (!c.prefs().getBoolean("ringing", false))
            c.prefs().edit().putBoolean("ringing", true).putLong("ramp", a.ramp).putInt("maxVol", a.maxVol)
                .putBoolean("vibrate", a.vibrate).putString("sound", a.sound)
                .putString("missions", JSONArray(a.missions).toString()).putString("objects", JSONArray(a.objects).toString()).putInt("missionIdx", 0).apply()
        c.sync(l)
        c.startForegroundService(Intent(c, AlarmService::class.java))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (c.prefs().getBoolean("ringing", false)) c.startForegroundService(Intent(c, AlarmService::class.java))
        val l = c.loadAlarms()
        l.filter { it.on && it.at > 0 }.forEach { c.arm(it, it.at) }
        c.sync(l)
    }
}

/** 화면이 꺼질 때마다 켜진 '화면 끈 뒤' 알람들을 (꺼진 시각 + n)으로 다시 맞춤. 그 시각이 규칙에 안 맞으면 예약 취소 */
class ScreenService : Service() {
    private val r = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val l = c.loadAlarms()
            l.filter { it.on && it.screen }.forEach {
                val t = Calendar.getInstance().apply { timeInMillis = System.currentTimeMillis() + it.dur }
                if (c.allowed(it, t)) c.arm(it, t.timeInMillis) else c.disarm(it)
            }
            c.saveAlarms(l)
        }
    }

    override fun onCreate() {
        registerReceiver(r, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg(2, "화면 꺼짐 대기 중", NotificationManager.IMPORTANCE_LOW)
        return START_STICKY
    }

    override fun onDestroy() = unregisterReceiver(r)
    override fun onBind(i: Intent?): IBinder? = null
}

/** 인증 전까지 계속 울림. 소리는 알람에 지정한 ramp 동안 점점 커져 최대에 도달 (0이면 처음부터 최대) */
class AlarmService : Service() {
    private lateinit var mp: MediaPlayer
    private val h = Handler(Looper.getMainLooper())
    private val start = SystemClock.elapsedRealtime()
    private var ramp = 0L
    private var max = 1f
    private fun vol() = max *
            if (ramp == 0L) 1f else ((SystemClock.elapsedRealtime() - start).toFloat() / ramp).coerceIn(0.05f, 1f)

    private val loud = object : Runnable {
        override fun run() {
            val am = getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            mp.setVolume(vol(), vol())
            h.postDelayed(this, 500)
        }
    }

    // 여러 알람이 겹쳐 다시 호출돼도 매번 포그라운드 유지
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ui = PendingIntent.getActivity(
            this, 2, Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        startFg(1, "샤워 인증 필요", NotificationManager.IMPORTANCE_HIGH, ui)
        // '다른 앱 위에 표시' 권한이 있으면 백그라운드에서도 미션 화면을 바로 띄울 수 있음 (화면 켜기는 AlarmActivity가 처리)
        startActivity(Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return START_STICKY
    }

    override fun onCreate() {
        ramp = prefs().getLong("ramp", 0)
        max = prefs().getInt("maxVol", 100) / 100f
        if (prefs().getBoolean("vibrate", false)) {
            @Suppress("DEPRECATION")
            getSystemService(Vibrator::class.java).vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            )
        }
        val sound = prefs().getString("sound", "")!!
        mp = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            setDataSource(
                this@AlarmService,
                if (sound.isEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) else Uri.parse(sound)
            )
            isLooping = true
            setVolume(vol(), vol())
            prepare()
            start()
        }
        h.post(loud)
    }

    override fun onDestroy() {
        h.removeCallbacks(loud)
        getSystemService(Vibrator::class.java).cancel()
        mp.release()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
