package com.showeralarm

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.net.Uri
import android.os.*
import androidx.core.app.ServiceCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

fun Context.prefs(): SharedPreferences = getSharedPreferences("p", Context.MODE_PRIVATE)

/** screen=false: 매일 h:m 의 다음 시각 / screen=true: 화면 꺼진 시각 + dur. ramp = 최대 볼륨까지 걸리는 시간(ms). sound = 알람음 파일 Uri("" 이면 기본 알람음). at = 현재 예약 시각(0이면 없음) */
data class Alarm(
    val id: Int, val screen: Boolean, val h: Int, val m: Int, val dur: Long,
    val ramp: Long, val sound: String, var on: Boolean, var at: Long
)

fun Context.loadAlarms(): MutableList<Alarm> = JSONArray(prefs().getString("alarms", "[]")).let { a ->
    MutableList(a.length()) {
        a.getJSONObject(it).run {
            Alarm(getInt("id"), getBoolean("screen"), getInt("h"), getInt("m"), getLong("dur"), getLong("ramp"), getString("sound"), getBoolean("on"), getLong("at"))
        }
    }
}

fun Context.saveAlarms(l: List<Alarm>) = prefs().edit().putString("alarms", JSONArray(l.map {
    JSONObject().put("id", it.id).put("screen", it.screen).put("h", it.h).put("m", it.m)
        .put("dur", it.dur).put("ramp", it.ramp).put("sound", it.sound).put("on", it.on).put("at", it.at)
}).toString()).apply()

private fun Context.pi(id: Int) = PendingIntent.getBroadcast(
    this, id, Intent(this, AlarmReceiver::class.java).putExtra("id", id),
    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)

fun Context.arm(a: Alarm, at: Long) {
    a.at = at
    val show = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(a.id))
}

private fun Context.disarm(a: Alarm) {
    a.at = 0
    getSystemService(AlarmManager::class.java).cancel(pi(a.id))
}

private fun nextTime(h: Int, m: Int) = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DATE, 1)
}.timeInMillis

/** 켜짐/꺼짐 상태에 맞춰 예약과 화면 감시 서비스를 정리하고 저장 */
fun Context.sync(l: List<Alarm>) {
    for (a in l) if (!a.on) disarm(a) else if (!a.screen && a.at == 0L) arm(a, nextTime(a.h, a.m))
    saveAlarms(l)
    val svc = Intent(this, ScreenService::class.java)
    if (l.any { it.on && it.screen }) startForegroundService(svc) else stopService(svc)
}

fun Service.startFg(id: Int, title: String, importance: Int, fullScreen: PendingIntent? = null) {
    val ch = "c$importance"
    getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, title, importance))
    val n = Notification.Builder(this, ch)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(title)
        .setOngoing(true)
        .apply {
            fullScreen?.let {
                setCategory(Notification.CATEGORY_ALARM)
                setFullScreenIntent(it, true)
                setContentIntent(it)
            }
        }.build()
    ServiceCompat.startForeground(this, id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
}

/** 울린 알람은 꺼짐 상태로 바뀜 (1회성) */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val l = c.loadAlarms()
        val a = l.first { it.id == id }.apply { on = false; at = 0 }
        // 이미 다른 알람이 울리는 중이면 그 알람의 커지는 시간을 유지
        if (!c.prefs().getBoolean("ringing", false))
            c.prefs().edit().putBoolean("ringing", true).putLong("ramp", a.ramp).putString("sound", a.sound).apply()
        c.sync(l)
        c.startForegroundService(Intent(c, AlarmService::class.java))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (c.prefs().getBoolean("ringing", false)) c.startForegroundService(Intent(c, AlarmService::class.java))
        val l = c.loadAlarms()
        l.filter { it.on && it.at > 0 }.forEach { c.arm(it, it.at) }
        c.sync(l)
    }
}

/** 화면이 꺼질 때마다 켜진 '화면 끈 뒤' 알람들을 (꺼진 시각 + n)으로 다시 맞춤 */
class ScreenService : Service() {
    private val r = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val l = c.loadAlarms()
            l.filter { it.on && it.screen }.forEach { c.arm(it, System.currentTimeMillis() + it.dur) }
            c.saveAlarms(l)
        }
    }

    override fun onCreate() {
        registerReceiver(r, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg(2, "화면 꺼짐 대기 중", NotificationManager.IMPORTANCE_LOW)
        return START_STICKY
    }

    override fun onDestroy() = unregisterReceiver(r)
    override fun onBind(i: Intent?): IBinder? = null
}

/** 인증 전까지 계속 울림. 소리는 알람에 지정한 ramp 동안 점점 커져 최대에 도달 (0이면 처음부터 최대) */
class AlarmService : Service() {
    private lateinit var mp: MediaPlayer
    private val h = Handler(Looper.getMainLooper())
    private val start = SystemClock.elapsedRealtime()
    private var ramp = 0L
    private fun vol() =
        if (ramp == 0L) 1f else ((SystemClock.elapsedRealtime() - start).toFloat() / ramp).coerceIn(0.05f, 1f)

    private val loud = object : Runnable {
        override fun run() {
            val am = getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            mp.setVolume(vol(), vol())
            h.postDelayed(this, 500)
        }
    }

    // 여러 알람이 겹쳐 다시 호출돼도 매번 포그라운드 유지
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ui = PendingIntent.getActivity(
            this, 2, Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        startFg(1, "샤워 인증 필요", NotificationManager.IMPORTANCE_HIGH, ui)
        return START_STICKY
    }

    override fun onCreate() {
        ramp = prefs().getLong("ramp", 0)
        val sound = prefs().getString("sound", "")!!
        mp = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            setDataSource(
                this@AlarmService,
                if (sound.isEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) else Uri.parse(sound)
            )
            isLooping = true
            setVolume(vol(), vol())
            prepare()
            start()
        }
        h.post(loud)
    }

    override fun onDestroy() {
        h.removeCallbacks(loud)
        mp.release()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
