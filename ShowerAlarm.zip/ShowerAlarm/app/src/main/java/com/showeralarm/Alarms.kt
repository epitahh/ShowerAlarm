package com.showeralarm

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.net.Uri
import android.os.*
import androidx.core.app.ServiceCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

fun Context.prefs(): SharedPreferences = getSharedPreferences("p", Context.MODE_PRIVATE)

val DAYS = arrayOf("일", "월", "화", "수", "목", "금", "토")

/**
 * screen=false: h:m 에 울림 / screen=true: 화면 꺼진 시각 + dur 에 울림
 * 반복 규칙: days(비트0=일 … 비트6=토, 0이면 반복 없음), skipHoliday(공휴일 제외), date("yyyy-MM-dd" 지정일, ""이면 없음)
 *   - screen 알람은 '꺼진 시각 + dur' 이 규칙에 맞을 때만 울림
 * ramp = 최대 볼륨까지 걸리는 시간(ms). maxVol = 최대 볼륨(%). vibrate = 진동 여부
 * sound = 알람음 목록(줄바꿈으로 구분, 순서대로 재생). 각 항목 ""이면 휴대폰 기본 알람음, "builtin:이름"이면 앱 내장음, 그 외는 파일 Uri. at = 현재 예약 시각(0이면 없음)
 * name = 알람 이름(없으면 "")
 * missions = 해제 미션 순서(중복 허용, MISSIONS의 미션 키). objects = 물건 찾기 후보(OBJECTS 키)
 */
data class Alarm(
    val id: Int, val name: String, val screen: Boolean, val h: Int, val m: Int, val dur: Long,
    val days: Int, val skipHoliday: Boolean, val date: String,
    val ramp: Long, val maxVol: Int, val vibrate: Boolean, val sound: String,
    val missions: List<String>, val objects: List<String>, var on: Boolean, var at: Long
)

private fun JSONArray.strings() = List(length()) { getString(it) }

/**
 * 저장된 알람 읽기. 이전 버전 형식이라 읽을 수 없거나(항목 누락) 지금 버전에서 오류가 날 알람
 * (모르는 미션·물건)은 예약을 취소하고 삭제함. 업데이트 직후(MY_PACKAGE_REPLACED)에도 호출되어 바로 정리됨
 */
fun Context.loadAlarms(): MutableList<Alarm> {
    val a = JSONArray(prefs().getString("alarms", "[]"))
    val l = mutableListOf<Alarm>()
    for (i in 0 until a.length()) {
        val o = a.getJSONObject(i)
        val alarm = runCatching {
            o.run {
                Alarm(
                    getInt("id"), getString("name"), getBoolean("screen"), getInt("h"), getInt("m"), getLong("dur"),
                    getInt("days"), getBoolean("skipHoliday"), getString("date"),
                    getLong("ramp"), getInt("maxVol"), getBoolean("vibrate"), getString("sound"),
                    getJSONArray("missions").strings(), getJSONArray("objects").strings(), getBoolean("on"), getLong("at")
                )
            }
        }.getOrNull()
        val ok = alarm != null &&
                alarm.missions.all { it == "shower" || it == "object" || Regex("pushup:\\d+").matches(it) } &&
                alarm.objects.all { it in OBJECTS }
        if (ok) l += alarm!! else if (o.has("id")) getSystemService(AlarmManager::class.java).cancel(pi(o.getInt("id")))
    }
    if (l.size != a.length()) saveAlarms(l)
    return l
}

fun Context.saveAlarms(l: List<Alarm>) = prefs().edit().putString("alarms", JSONArray(l.map {
    JSONObject().put("id", it.id).put("name", it.name).put("screen", it.screen).put("h", it.h).put("m", it.m).put("dur", it.dur)
        .put("days", it.days).put("skipHoliday", it.skipHoliday).put("date", it.date)
        .put("ramp", it.ramp).put("maxVol", it.maxVol).put("vibrate", it.vibrate).put("sound", it.sound)
        .put("missions", JSONArray(it.missions)).put("objects", JSONArray(it.objects))
        .put("on", it.on).put("at", it.at)
}).toString()).apply()

// 빌드 시 받아 넣은 공휴일 목록 (yyyyMMdd)
private var holidays: Set<String>? = null

private fun Context.isHoliday(c: Calendar): Boolean {
    val s = holidays ?: assets.open("holidays.txt").bufferedReader().readLines().toSet().also { holidays = it }
    return "%04d%02d%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)) in s
}

/** 해당 시각이 알람의 반복 규칙(지정일·요일·공휴일 제외)에 맞는지 */
private fun Context.allowed(a: Alarm, c: Calendar) =
    (a.date.isEmpty() || a.date == "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))) &&
            (a.days == 0 || ((a.days shr (c.get(Calendar.DAY_OF_WEEK) - 1)) and 1) == 1) &&
            !(a.skipHoliday && isHoliday(c))

/** '특정 시각' 알람의 다음 울릴 시각 (지정일이면 그 날짜의 시각) */
fun Context.nextTime(a: Alarm): Long {
    val c = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, a.h); set(Calendar.MINUTE, a.m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    if (a.date.isNotEmpty()) {
        val (y, mo, d) = a.date.split("-").map { it.toInt() }
        c.set(y, mo - 1, d)
        return c.timeInMillis
    }
    val skip = skipUntil(a.id)
    while (c.timeInMillis <= System.currentTimeMillis() || !allowed(a, c) || c.timeInMillis <= skip) c.add(Calendar.DATE, 1)
    return c.timeInMillis
}

/** '화면 끈 뒤' 알람의 울림 시각 구간 (분 단위 시작, 끝; 자정을 넘을 수 있음). 알람 데이터와 따로 저장, 없으면 null */
fun Context.windowOf(id: Int): Pair<Int, Int>? =
    prefs().getString("win$id", "")!!.takeIf { it.isNotEmpty() }?.split(",")?.let { it[0].toInt() to it[1].toInt() }

fun Context.setWindow(id: Int, w: Pair<Int, Int>?) =
    prefs().edit().putString("win$id", w?.let { "${it.first},${it.second}" } ?: "").apply()

/** 시각 c가 구간 안인지 (구간이 없으면 항상 참) */
fun inWindow(w: Pair<Int, Int>?, c: Calendar): Boolean {
    w ?: return true
    val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    return if (w.first <= w.second) m in w.first..w.second else m >= w.first || m <= w.second
}

/** 앱 내장 알람음 (res/raw/snd_이름.wav, tools/make_sounds.py로 합성) */
val BUILTIN_SOUNDS = linkedMapOf(
    "low_t3" to "저주파 경보 (화재경보기 패턴)", "beep" to "디지털 비프", "fast_beep" to "빠른 비프", "siren" to "사이렌",
    "buzzer" to "저음 버저", "horn" to "경적", "rising" to "상승음", "chirp" to "처프",
    "melody" to "아침 멜로디", "marimba" to "마림바", "chime" to "차임", "pulse" to "점점 빨라지는 맥박"
)

fun Context.soundUri(sound: String): Uri = when {
    sound.isEmpty() -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
    sound.startsWith("builtin:") -> Uri.parse("android.resource://$packageName/raw/snd_${sound.removePrefix("builtin:")}")
    else -> Uri.parse(sound)
}

/** 알람음 목록 표시 이름 (여러 개면 화살표로 연결) */
fun soundNames(s: String) = soundsOf(s).joinToString(" → ") { soundName(it) }

fun soundName(sound: String) = when {
    sound.isEmpty() -> "휴대폰 기본 알람음"
    sound.startsWith("builtin:") -> BUILTIN_SOUNDS[sound.removePrefix("builtin:")]!!
    else -> "파일 알람음"
}

/** 알람 연결 그룹 번호 (알람 데이터와 따로 저장, 0이면 연결 없음) */
fun Context.linkOf(id: Int) = prefs().getInt("link$id", 0)

fun Context.setLink(id: Int, group: Int) = prefs().edit().putInt("link$id", group).apply()

/**
 * 연결된 알람 중 하나(a)가 울리면 같은 날 남은 다른 알람은 울리지 않게 함:
 * 반복 알람은 오늘 끝까지 건너뜀, 한 번 알람은 오늘 울릴 예정이면 끔 ('화면 끈 뒤'는 오늘 울릴 수 있으므로 끔)
 */
fun Context.cancelLinked(l: List<Alarm>, a: Alarm) {
    val g = linkOf(a.id)
    if (g == 0) return
    val endOfDay = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
    }.timeInMillis
    for (b in l) {
        if (b.id == a.id || !b.on || linkOf(b.id) != g) continue
        if (b.days != 0) { setSkip(b.id, maxOf(skipUntil(b.id), endOfDay)); disarm(b) }
        else if (b.screen || b.at <= endOfDay) { b.on = false; disarm(b) }
    }
}

/** '다음 알람만 건너뛰기': 이 시각 이하의 회차는 울리지 않음 (알람 데이터와 따로 저장, 0이면 없음) */
fun Context.skipUntil(id: Int) = prefs().getLong("skip$id", 0)

fun Context.setSkip(id: Int, t: Long) = prefs().edit().putLong("skip$id", t).apply()

/**
 * 반복 알람의 바로 다음 회차만 건너뛰고 켜기.
 * 특정 시각 알람은 다음 울릴 시각까지, '화면 끈 뒤' 알람은 오늘부터 처음 오는 해당 요일 하루 전체를 건너뜀
 */
fun Context.skipNext(l: List<Alarm>, id: Int) {
    val a = l.first { it.id == id }
    setSkip(id, 0)
    setSkip(id, if (!a.screen) nextTime(a) else Calendar.getInstance().run {
        set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
        while (!allowed(a, this)) add(Calendar.DATE, 1)
        timeInMillis
    })
    a.on = true; a.at = 0
    sync(l)
}

private fun Context.pi(id: Int) = PendingIntent.getBroadcast(
    this, id, Intent(this, AlarmReceiver::class.java).putExtra("id", id),
    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)

fun Context.arm(a: Alarm, at: Long) {
    a.at = at
    val show = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(a.id))
}

fun Context.disarm(a: Alarm) {
    a.at = 0
    getSystemService(AlarmManager::class.java).cancel(pi(a.id))
}

/** 켜짐/꺼짐 상태에 맞춰 예약과 화면 감시 서비스를 정리하고 저장. 지난 지정일 알람은 꺼짐 처리 */
fun Context.sync(l: List<Alarm>) {
    for (a in l) {
        if (a.on && !a.screen && a.at == 0L) {
            val t = nextTime(a)
            if (t > System.currentTimeMillis()) arm(a, t) else a.on = false
        }
        if (!a.on) disarm(a)
    }
    saveAlarms(l)
    val svc = Intent(this, ScreenService::class.java)
    if (l.any { it.on && it.screen }) startForegroundService(svc) else stopService(svc)
}

fun Service.startFg(id: Int, title: String, importance: Int, fullScreen: PendingIntent? = null) {
    val ch = "c$importance"
    getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, title, importance))
    val n = Notification.Builder(this, ch)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(title)
        .setOngoing(true)
        .apply {
            fullScreen?.let {
                setCategory(Notification.CATEGORY_ALARM)
                setFullScreenIntent(it, true)
                setContentIntent(it)
            }
        }.build()
    ServiceCompat.startForeground(this, id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
}

/** 요일 반복 알람은 다음 회차로 다시 예약, 그 외(한 번·지정일)는 울린 뒤 꺼짐 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val l = c.loadAlarms()
        val a = l.find { it.id == id }?.apply { at = 0; if (days == 0) on = false } ?: return
        // 이미 다른 알람이 울리는 중이면 그 알람의 커지는 시간을 유지
        if (!c.prefs().getBoolean("ringing", false))
            c.prefs().edit().putBoolean("ringing", true).putLong("ramp", a.ramp).putInt("maxVol", a.maxVol)
                .putBoolean("vibrate", a.vibrate).putString("sound", a.sound).putInt("gap", c.gapOf(a.id))
                .putString("missions", JSONArray(a.missions).toString()).putString("objects", JSONArray(a.objects).toString()).putInt("missionIdx", 0).apply()
        c.cancelLinked(l, a)
        c.sync(l)
        c.startForegroundService(Intent(c, AlarmService::class.java))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (c.prefs().getBoolean("ringing", false)) c.startForegroundService(Intent(c, AlarmService::class.java))
        // 꺼져 있는 동안 지난 알람은 건너뜀 (한 번 알람은 울린 것처럼 꺼짐, 반복은 다음 회차로). 울리던 중이던 알람은 계속 울림
        val l = c.loadAlarms()
        val now = System.currentTimeMillis()
        for (a in l.filter { it.on && it.at > 0 }) {
            if (a.at > now) c.arm(a, a.at)
            else { c.disarm(a); if (a.days == 0) a.on = false }
        }
        c.sync(l)
    }
}

/** 화면이 꺼질 때마다 켜진 '화면 끈 뒤' 알람들을 (꺼진 시각 + n)으로 다시 맞춤. 그 시각이 규칙(요일·공휴일·건너뛰기·울림 구간)에 안 맞으면 예약 취소 */
class ScreenService : Service() {
    private val r = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val l = c.loadAlarms()
            l.filter { it.on && it.screen }.forEach {
                val t = Calendar.getInstance().apply { timeInMillis = System.currentTimeMillis() + it.dur }
                if (c.allowed(it, t) && t.timeInMillis > c.skipUntil(it.id) && inWindow(c.windowOf(it.id), t)) c.arm(it, t.timeInMillis)
                else c.disarm(it)
            }
            c.saveAlarms(l)
        }
    }

    override fun onCreate() {
        registerReceiver(r, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg(2, "화면 꺼짐 대기 중", NotificationManager.IMPORTANCE_MIN)
        return START_STICKY
    }

    override fun onDestroy() = unregisterReceiver(r)
    override fun onBind(i: Intent?): IBinder? = null
}

const val QUIET = "quiet"

/** 인증 전까지 계속 울림. 소리는 알람에 지정한 ramp 동안 점점 커져 최대에 도달 (0이면 처음부터 최대) */
class AlarmService : Service() {
    private lateinit var mp: SoundPlayer
    private val h = Handler(Looper.getMainLooper())
    private val start = SystemClock.elapsedRealtime()
    private var ramp = 0L
    private var max = 1f
    private var quietUntil = 0L // 소리 줄이기 끝나는 시각 (elapsedRealtime)
    private var buzzing = false
    private fun vol() = max *
            (if (ramp == 0L) 1f else ((SystemClock.elapsedRealtime() - start).toFloat() / ramp).coerceIn(0.05f, 1f))

    @Suppress("DEPRECATION")
    private fun vibrate(on: Boolean) {
        if (on == buzzing || !prefs().getBoolean("vibrate", false)) return
        buzzing = on
        val v = getSystemService(Vibrator::class.java)
        if (on) v.vibrate(
            VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
        ) else v.cancel()
    }

    /**
     * 0.5초마다 알람 음량을 최대로(소리 줄이기 중엔 최대의 quietPct%로) 맞추고, 소리 줄이기 중엔 진동을 끔.
     * 소리 줄이기를 개별 플레이어가 아닌 알람 음량으로 적용해, 알람음이 여러 개여도 지금 울리는 소리에 그대로 적용됨
     */
    private val loud = object : Runnable {
        override fun run() {
            val quiet = SystemClock.elapsedRealtime() < quietUntil
            val am = getSystemService(AudioManager::class.java)
            val top = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, if (quiet) top * prefs().getInt("quietPct", 50) / 100 else top, 0)
            vibrate(!quiet)
            mp.volume = vol()
            h.postDelayed(this, 500)
        }
    }

    // 여러 알람이 겹쳐 다시 호출돼도 매번 포그라운드 유지
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        // 미션 화면의 '소리 줄이기': 설정한 시간 동안 설정한 비율로 (쿨타임 없음, 누를 때마다 다시 시작)
        if (i?.action == QUIET) {
            quietUntil = SystemClock.elapsedRealtime() + prefs().getInt("quietSec", 10) * 1000L
            h.removeCallbacks(loud); loud.run() // 바로 적용
            return START_STICKY
        }
        val ui = PendingIntent.getActivity(
            this, 2, Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        startFg(1, "샤워 인증 필요", NotificationManager.IMPORTANCE_HIGH, ui)
        // '다른 앱 위에 표시' 권한이 있으면 백그라운드에서도 미션 화면을 바로 띄울 수 있음 (화면 켜기는 AlarmActivity가 처리)
        startActivity(Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return START_STICKY
    }

    override fun onCreate() {
        ramp = prefs().getLong("ramp", 0)
        max = prefs().getInt("maxVol", 100) / 100f
        // 알람음 여러 개면 정한 간격마다 순서대로 바꿔 가며 반복
        mp = SoundPlayer(this, soundsOf(prefs().getString("sound", "")!!), prefs().getInt("gap", 30) * 1000L)
            .apply { volume = vol(); start() }
        h.post(loud)
    }

    override fun onDestroy() {
        h.removeCallbacks(loud)
        getSystemService(Vibrator::class.java).cancel()
        mp.stop()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
