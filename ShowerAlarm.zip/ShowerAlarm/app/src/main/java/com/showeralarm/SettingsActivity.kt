package com.showeralarm

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity

/** 메인 화면의 설정: 소리 줄이기 버튼 설정, 미션별 테스트 */
class SettingsActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                // 미션 중 '소리 줄이기' 버튼: 몇 초 동안, 몇 %로 줄일지 (바로 저장)
                addView(TextView(context).apply { text = "소리 줄이기 버튼"; textSize = 18f })
                val secText = TextView(context)
                addView(secText)
                addView(NumberPicker(context).apply {
                    minValue = 1; maxValue = 120; value = prefs().getInt("quietSec", 10)
                    secText.text = "지속 시간: ${value}초"
                    setOnValueChangedListener { _, _, v -> prefs().edit().putInt("quietSec", v).apply(); secText.text = "지속 시간: ${v}초" }
                })
                val pctText = TextView(context)
                addView(pctText)
                addView(SeekBar(context).apply {
                    max = 100; progress = prefs().getInt("quietPct", 50)
                    pctText.text = "줄인 소리 크기: 원래의 $progress%"
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                            prefs().edit().putInt("quietPct", p).apply(); pctText.text = "줄인 소리 크기: 원래의 $p%"
                        }
                        override fun onStartTrackingTouch(s: SeekBar) {}
                        override fun onStopTrackingTouch(s: SeekBar) {}
                    })
                })
                addView(TextView(context).apply { text = "미션 테스트 (알람 없이 해보기)"; textSize = 18f; setPadding(0, 48, 0, 24) })
                addView(Button(context).apply { text = "샤워 인증"; setOnClickListener { test("shower") } })
                // 물건 찾기는 전체 물건 중 무작위
                addView(Button(context).apply { text = "물건 찾기"; setOnClickListener { test("object") } })
                addView(Button(context).apply {
                    text = "푸시업"
                    setOnClickListener {
                        val n = NumberPicker(context).apply { minValue = 1; maxValue = 100; value = 10 }
                        AlertDialog.Builder(this@SettingsActivity).setTitle("푸시업 몇 개?").setView(n)
                            .setPositiveButton("시작") { _, _ -> test("pushup:${n.value}") }
                            .show()
                    }
                })
            })
        })
    }

    private fun test(mission: String) = startActivity(
        Intent(this, AlarmActivity::class.java).putExtra("test", true)
            .putExtra("missions", arrayOf(mission)).putExtra("objects", OBJECTS.keys.toTypedArray())
    )
}
