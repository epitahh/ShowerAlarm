package com.showeralarm

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.ComponentActivity

/** 메인 화면의 설정: 소리 줄이기 버튼 설정, 미션별 테스트 */
class SettingsActivity : ComponentActivity() {
    private lateinit var ml: MissionList

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // 알람 편집과 같은 방식으로 미션을 쌓아서 알람 없이 순서대로 해보기
        ml = MissionList(this, emptyList(), emptyList())
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 48, 48, 48)
                // 미션 중 '소리 줄이기' 버튼: 몇 초 동안, 몇 %로 줄일지 (바로 저장)
                addView(TextView(context).apply { text = "소리 줄이기 버튼"; textSize = 18f })
                val secText = TextView(context)
                addView(secText)
                addView(NumberPicker(context).apply {
                    minValue = 1; maxValue = 120; value = prefs().getInt("quietSec", 10)
                    secText.text = "지속 시간: ${value}초"
                    setOnValueChangedListener { _, _, v -> prefs().edit().putInt("quietSec", v).apply(); secText.text = "지속 시간: ${v}초" }
                })
                val pctText = TextView(context)
                addView(pctText)
                addView(SeekBar(context).apply {
                    max = 100; progress = prefs().getInt("quietPct", 50)
                    pctText.text = "줄인 소리 크기: 원래의 $progress%"
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                            prefs().edit().putInt("quietPct", p).apply(); pctText.text = "줄인 소리 크기: 원래의 $p%"
                        }
                        override fun onStartTrackingTouch(s: SeekBar) {}
                        override fun onStopTrackingTouch(s: SeekBar) {}
                    })
                })
                addView(TextView(context).apply { text = "미션 테스트 (알람 없이 해보기)"; textSize = 18f; setPadding(0, 48, 0, 24) })
                addView(ml.view)
                addView(Button(context).apply { text = "테스트 시작"; setOnClickListener { test() } })
            })
        })
    }

    private fun test() {
        if (!ml.valid()) return
        startActivity(
            Intent(this, AlarmActivity::class.java).putExtra("test", true)
                .putExtra("missions", ml.missions.toTypedArray()).putExtra("objects", ml.objects.toTypedArray())
        )
    }
}
