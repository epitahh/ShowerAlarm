package com.showeralarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

/** 메인 화면의 설정: 상단 탭으로 '소리 줄이기' · '미션 테스트' · '알림'을 나눔 */
class SettingsActivity : ComponentActivity() {
    private lateinit var ml: MissionList

    // 마지막 푸시업 진단 로그를 사용자가 고른 위치(다운로드 등)에 저장
    private val saveLog = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) contentResolver.openOutputStream(uri)!!.use { File(filesDir, PushupMission.LOG_FILE).inputStream().copyTo(it) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // 알람 편집과 같은 방식으로 미션을 쌓아서 알람 없이 순서대로 해보기
        ml = MissionList(this, emptyList(), emptyList())

        val pages = listOf(quietPage(), testPage(), notiPage())
        val tabs = listOf("소리 줄이기", "미션 테스트", "알림").map { t ->
            TextView(this).apply { text = t; textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 32, 0, 32) }
        }
        fun select(i: Int) {
            pages.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
            tabs.forEachIndexed { j, t ->
                t.setTypeface(null, if (i == j) Typeface.BOLD else Typeface.NORMAL)
                t.setTextColor(if (i == j) Color.BLACK else Color.GRAY)
            }
        }
        tabs.forEachIndexed { i, t -> t.setOnClickListener { select(i) } }
        select(0)

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(LinearLayout(context).apply {
                tabs.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
            })
            addView(FrameLayout(context).apply { pages.forEach { addView(it) } },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
    }

    private fun page(build: LinearLayout.() -> Unit) = ScrollView(this).apply {
        addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 24, 48, 48); build() })
    }

    /** 미션 중 '소리 줄이기' 버튼: 몇 초 동안, 몇 %로 줄일지 (바로 저장) */
    private fun quietPage() = page {
        val secText = TextView(context)
        addView(secText)
        addView(NumberPicker(context).apply {
            minValue = 1; maxValue = 120; value = prefs().getInt("quietSec", 10)
            secText.text = "지속 시간: ${value}초"
            setOnValueChangedListener { _, _, v -> prefs().edit().putInt("quietSec", v).apply(); secText.text = "지속 시간: ${v}초" }
        })
        val pctText = TextView(context)
        addView(pctText)
        addView(SeekBar(context).apply {
            max = 100; progress = prefs().getInt("quietPct", 50)
            pctText.text = "줄인 소리 크기: 원래의 $progress%"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    prefs().edit().putInt("quietPct", p).apply(); pctText.text = "줄인 소리 크기: 원래의 $p%"
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })
    }

    /**
     * '화면 꺼짐 대기 중' 알림 숨기기: 대기 서비스는 알림이 꺼져도 계속 동작함 (Android 문서: 알림 권한이 없어도
     * 포그라운드 서비스는 실행되고 알림만 안 보임). 해당 채널 설정 화면을 열어 사용자가 끄게 함
     */
    private fun notiPage() = page {
        addView(TextView(context).apply {
            text = "'화면 꺼짐 대기 중' 알림을 꺼도 '화면 끈 뒤' 알람은 그대로 동작해요.\n아래 버튼을 눌러 나오는 화면에서 알림을 꺼 주세요."
            textSize = 16f; setPadding(0, 0, 0, 24)
        })
        addView(Button(context).apply {
            text = "'화면 꺼짐 대기 중' 알림 설정 열기"
            setOnClickListener {
                val ch = "c${NotificationManager.IMPORTANCE_MIN}" // startFg가 쓰는 채널 id 규칙과 같음
                getSystemService(NotificationManager::class.java)
                    .createNotificationChannel(NotificationChannel(ch, "화면 꺼짐 대기 중", NotificationManager.IMPORTANCE_MIN))
                startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName).putExtra(Settings.EXTRA_CHANNEL_ID, ch))
            }
        })
    }

    /** 미션을 쌓아서 알람 없이 해보기 */
    private fun testPage() = page {
        addView(ml.view)
        addView(Button(context).apply { text = "테스트 시작"; setOnClickListener { test() } })
        addView(Button(context).apply {
            text = "마지막 푸시업 로그 저장"
            setOnClickListener {
                if (File(filesDir, PushupMission.LOG_FILE).exists()) saveLog.launch("pushup_log.csv")
                else Toast.makeText(context, "아직 푸시업 기록이 없어요", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun test() {
        if (!ml.valid()) return
        startActivity(
            Intent(this, AlarmActivity::class.java).putExtra("test", true)
                .putExtra("missions", ml.missions.toTypedArray()).putExtra("objects", ml.objects.toTypedArray())
        )
    }
}
