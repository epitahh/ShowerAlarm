plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.showeralarm"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.showeralarm"
        minSdk = 27
        targetSdk = 34
        versionCode = System.getenv("VERSION_CODE").toInt()
        versionName = "1.6.1" // 수정할 때마다 올림. 릴리스 태그(v1.0.0)로도 쓰임
        ndk { abiFilters += "arm64-v8a" } // 휴대폰용 64비트 ARM만 포함 (x86 등 에뮬레이터용 제외)
    }
    packaging { jniLibs.useLegacyPackaging = true } // 네이티브 라이브러리를 압축해 APK 크기 축소
    signingConfigs {
        create("release") {
            storeFile = file("../release.jks")
            storePassword = System.getenv("KEYSTORE_PASS")
            keyAlias = "key"
            keyPassword = System.getenv("KEYSTORE_PASS")
        }
    }
    buildTypes {
        getByName("release") { signingConfig = signingConfigs.getByName("release") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    val camerax = "1.6.2"
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")
    implementation("com.google.mlkit:pose-detection:18.0.0-beta5")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.27.0")
}
