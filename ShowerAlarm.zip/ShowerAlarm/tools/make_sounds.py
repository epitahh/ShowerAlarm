# 앱 내장 알람음 합성 → app/src/main/res/raw/snd_*.wav (22.05kHz, 16bit, mono, 반복 재생용 길이)
# 근거: 저주파(400~520Hz) 사각파가 높은 음보다 잘 깨운다는 Bruck·Ball(빅토리아대) 화재경보기 연구,
#       멜로디 알람음이 수면 관성 감소와 관련 있다는 McFarlane 등(2020, PLOS ONE)
import os, wave
import numpy as np

SR = 22050
OUT = "app/src/main/res/raw"


def t(sec): return np.arange(int(SR * sec)) / SR


def square(f, sec): return np.sign(np.sin(2 * np.pi * f * t(sec)))


def saw(f, sec): x = t(sec) * f; return 2 * (x - np.floor(x + 0.5))


def silence(sec): return np.zeros(int(SR * sec))


def fade(x, ms=8):
    n = min(int(SR * ms / 1000), len(x) // 2)
    if n: x[:n] *= np.linspace(0, 1, n); x[-n:] *= np.linspace(1, 0, n)
    return x


def note(f, sec, decay=4.0, partials=((1, 1), (2, .4), (3, .2))):
    tt = t(sec)
    x = sum(a * np.sin(2 * np.pi * f * k * tt) for k, a in partials)
    return fade(x * np.exp(-decay * tt), 5)


def cat(*xs): return np.concatenate(xs)


C5, D5, E5, G5, A5, C6 = 523.25, 587.33, 659.25, 783.99, 880.0, 1046.5

S = {
    # 화재경보기 T3 패턴 (0.5초 울림·0.5초 쉼 ×3, 1.5초 쉼), 520Hz 사각파
    "low_t3": cat(*[cat(fade(square(520, .5)), silence(.5)) for _ in range(3)], silence(1.0)),
    # 디지털 시계식 비프 4번
    "beep": cat(*[cat(fade(square(2000, .08), 3), silence(.07)) for _ in range(4)], silence(.5)),
    # 빠른 비프
    "fast_beep": cat(*[cat(fade(square(880, .1), 3), silence(.1)) for _ in range(5)]),
    # 사이렌 (600↔1400Hz 왕복)
    "siren": np.tanh(3 * np.sin(2 * np.pi * np.cumsum(1000 + 400 * np.sin(2 * np.pi * .5 * t(2.0))) / SR)),
    # 저음 버저
    "buzzer": cat(fade(saw(150, .6)), silence(.3)),
    # 경적 (420+500Hz 사각파 화음)
    "horn": cat(fade(square(420, .4) + square(500, .4)), silence(.2)),
    # 상승음 (300→1500Hz)
    "rising": cat(fade(np.sign(np.sin(2 * np.pi * np.cumsum(np.linspace(300, 1500, int(SR * 1.5))) / SR))), silence(.3)),
    # 처프 (빠르게 올라가는 짧은 소리)
    "chirp": cat(*[cat(fade(np.sin(2 * np.pi * np.cumsum(np.linspace(1000, 3000, int(SR * .12))) / SR), 3), silence(.08)) for _ in range(3)], silence(.4)),
    # 아침 멜로디 (도미솔도솔미)
    "melody": cat(*[note(f, .3) for f in (C5, E5, G5, C6, G5, E5)]),  # 끝 쉼 없이 박자 그대로 반복
    # 마림바풍 5음 음계 선율
    "marimba": cat(*[note(f, .25, decay=9, partials=((1, 1), (4, .25))) for f in (C5, D5, E5, G5, A5, G5, E5, D5)]),  # 끝 쉼 없이 박자 그대로 반복
    # 차임 (비정수배 배음이 섞인 종소리 두 음)
    "chime": cat(note(G5, 1.0, 2.5, ((1, 1), (2.76, .5), (5.4, .25))), note(C5, 1.4, 2.0, ((1, 1), (2.76, .5), (5.4, .25)))),
    # 낮은 맥박 (점점 빨라지는 쿵쿵)
    "pulse": cat(*[cat(fade(np.sin(2 * np.pi * 80 * t(.12)) * np.exp(-20 * t(.12)), 3), silence(g)) for g in (.5, .4, .3, .2, .15, .1)], silence(.4)),
}

os.makedirs(OUT, exist_ok=True)
for name, x in S.items():
    x = x / np.max(np.abs(x)) * 0.89  # 최대 -1dBFS로 맞춤
    with wave.open(f"{OUT}/snd_{name}.wav", "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype("<i2").tobytes())
    print(name, f"{len(x) / SR:.2f}s")
