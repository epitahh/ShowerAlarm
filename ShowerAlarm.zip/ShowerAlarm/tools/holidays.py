# 빌드 시 한국천문연구원 특일 정보(getRestDeInfo)로 올해·내년 공휴일(isHoliday=Y)을 받아 앱 assets에 저장
import datetime, json, os, sys, time, urllib.parse, urllib.request

URL = "https://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getRestDeInfo"


def get(url):
    # 해외(GitHub 서버)에서 접속이 가끔 끊기거나 멈춰서, 30초 제한 + 최대 5회 재시도
    for i in range(5):
        try:
            return urllib.request.urlopen(url, timeout=30).read().decode()
        except OSError as e:
            if i == 4:
                raise
            print(f"재시도 {i + 1}/4: {e}")
            time.sleep(10)

key = os.environ["HOLIDAY_KEY"]
year = datetime.date.today().year
days = []
for y in (year, year + 1):
    for m in range(1, 13):
        q = urllib.parse.urlencode({"ServiceKey": key, "solYear": y, "solMonth": f"{m:02d}", "_type": "json", "numOfRows": 100})
        raw = get(f"{URL}?{q}")
        try:
            r = json.loads(raw)["response"]
        except (ValueError, KeyError):
            sys.exit("API 응답 오류: " + raw[:500])
        if r["header"]["resultCode"] != "00":
            sys.exit("API 오류: " + json.dumps(r["header"], ensure_ascii=False))
        items = r["body"]["items"]
        items = items["item"] if items else []  # 공휴일 없는 달은 items가 빈 값
        if isinstance(items, dict):  # 1건이면 리스트가 아닌 객체로 옴
            items = [items]
        days += [str(i["locdate"]) for i in items if i["isHoliday"] == "Y"]

os.makedirs("app/src/main/assets", exist_ok=True)
open("app/src/main/assets/holidays.txt", "w").write("\n".join(days))
print(f"{len(days)} holidays:", " ".join(days))
