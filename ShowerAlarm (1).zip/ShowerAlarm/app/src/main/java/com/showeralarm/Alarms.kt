package com.showeralarm

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import androidx.core.app.ServiceCompat

fun Context.prefs(): SharedPreferences = getSharedPreferences("p", Context.MODE_PRIVATE)

private fun Context.alarmPi() = PendingIntent.getBroadcast(
    this, 0, Intent(this, AlarmReceiver::class.java),
    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
)

fun Context.scheduleAlarm(at: Long) {
    prefs().edit().putLong("at", at).apply()
    val show = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), alarmPi())
}

fun Context.cancelAlarm() {
    prefs().edit().putLong("at", 0).apply()
    getSystemService(AlarmManager::class.java).cancel(alarmPi())
}

fun Service.startFg(id: Int, title: String, importance: Int, fullScreen: PendingIntent? = null) {
    val ch = "c$importance"
    getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, title, importance))
    val n = Notification.Builder(this, ch)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(title)
        .setOngoing(true)
        .apply {
            fullScreen?.let {
                setCategory(Notification.CATEGORY_ALARM)
                setFullScreenIntent(it, true)
                setContentIntent(it)
            }
        }.build()
    ServiceCompat.startForeground(this, id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.prefs().edit().putBoolean("ringing", true).putLong("at", 0).putLong("dur", 0).apply()
        c.stopService(Intent(c, ScreenService::class.java))
        c.startForegroundService(Intent(c, AlarmService::class.java))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val p = c.prefs()
        if (p.getBoolean("ringing", false)) c.startForegroundService(Intent(c, AlarmService::class.java))
        if (p.getLong("at", 0) > 0) c.scheduleAlarm(p.getLong("at", 0))
        if (p.getLong("dur", 0) > 0) c.startForegroundService(Intent(c, ScreenService::class.java))
    }
}

/** 화면이 꺼질 때마다 (꺼진 시각 + n) 으로 알람을 다시 맞춤 */
class ScreenService : Service() {
    private val r = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) =
            c.scheduleAlarm(System.currentTimeMillis() + c.prefs().getLong("dur", 0))
    }

    override fun onCreate() {
        startFg(2, "화면 꺼짐 대기 중", NotificationManager.IMPORTANCE_LOW)
        registerReceiver(r, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onDestroy() = unregisterReceiver(r)
    override fun onBind(i: Intent?): IBinder? = null
}

/** 인증 전까지 계속 울림. 소리는 RAMP_MS 동안 점점 커져 최대에 도달 */
class AlarmService : Service() {
    private lateinit var mp: MediaPlayer
    private val h = Handler(Looper.getMainLooper())
    private val start = SystemClock.elapsedRealtime()
    private val loud = object : Runnable {
        override fun run() {
            val am = getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            val v = ((SystemClock.elapsedRealtime() - start).toFloat() / RAMP_MS).coerceIn(0.05f, 1f)
            mp.setVolume(v, v)
            h.postDelayed(this, 500)
        }
    }

    companion object { const val RAMP_MS = 30_000L }

    override fun onCreate() {
        val ui = PendingIntent.getActivity(
            this, 2, Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        startFg(1, "샤워 인증 필요", NotificationManager.IMPORTANCE_HIGH, ui)
        mp = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            setDataSource(this@AlarmService, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            isLooping = true
            setVolume(0.05f, 0.05f)
            prepare()
            start()
        }
        h.post(loud)
    }

    override fun onDestroy() {
        h.removeCallbacks(loud)
        mp.release()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
