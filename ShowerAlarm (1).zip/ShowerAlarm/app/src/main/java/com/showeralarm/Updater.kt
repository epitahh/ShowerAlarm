package com.showeralarm

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.pm.PackageInfoCompat
import java.net.URL
import kotlin.concurrent.thread

private const val BASE = "https://github.com/epitahh/ShowerAlarm/releases/latest/download"

/** 최신 Release의 version.txt가 현재 versionCode보다 크면 APK를 받아 자기 자신을 업데이트 */
fun Context.checkUpdate() = thread {
    runCatching {
        val latest = URL("$BASE/version.txt").readText().trim().toLong()
        if (latest <= PackageInfoCompat.getLongVersionCode(packageManager.getPackageInfo(packageName, 0))) return@thread
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return@thread
        }
        val pi = packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            if (Build.VERSION.SDK_INT >= 31) setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        pi.openSession(pi.createSession(params)).use { s ->
            URL("$BASE/ShowerAlarm.apk").openStream().use { input ->
                s.openWrite("apk", 0, -1).use { out -> input.copyTo(out); s.fsync(out) }
            }
            s.commit(
                PendingIntent.getBroadcast(
                    this, 3, Intent(this, InstallReceiver::class.java),
                    PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                ).intentSender
            )
        }
    }
}

/** 조건 미충족(Android 12 미만 등)으로 확인이 필요하면 시스템 확인 화면을 띄움 */
class InstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        if (i.getIntExtra(PackageInstaller.EXTRA_STATUS, 0) == PackageInstaller.STATUS_PENDING_USER_ACTION)
            c.startActivity(i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
