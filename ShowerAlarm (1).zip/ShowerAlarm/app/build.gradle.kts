plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.showeralarm"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.showeralarm"
        minSdk = 27
        targetSdk = 34
        versionCode = System.getenv("VERSION_CODE").toInt()
        versionName = System.getenv("VERSION_CODE")
    }
    signingConfigs {
        create("release") {
            storeFile = file("../release.jks")
            storePassword = System.getenv("KEYSTORE_PASS")
            keyAlias = "key"
            keyPassword = System.getenv("KEYSTORE_PASS")
        }
    }
    buildTypes {
        getByName("release") { signingConfig = signingConfigs.getByName("release") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    val camerax = "1.6.2"
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")
    implementation("com.google.mlkit:pose-detection:18.0.0-beta5")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.27.0")
}
